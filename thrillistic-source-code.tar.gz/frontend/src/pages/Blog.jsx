import React, { useState } from 'react';
import { Clock, User, Calendar } from 'lucide-react';
import { toast } from 'sonner';
import axios from 'axios';
import { blogPosts } from '../data/mockData';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const Blog = () => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [isSubscribing, setIsSubscribing] = useState(false);

  const handleNewsletterSubmit = async (e) => {
    e.preventDefault();
    
    if (!newsletterEmail) {
      toast.error('Please enter your email address');
      return;
    }

    setIsSubscribing(true);

    try {
      const response = await axios.post(`${BACKEND_URL}/api/newsletter/subscribe`, {
        email: newsletterEmail
      });
      
      if (response.data.success) {
        toast.success(response.data.message);
        setNewsletterEmail('');
      }
    } catch (error) {
      console.error('Newsletter subscription error:', error);
      toast.error('Failed to subscribe. Please try again later.');
    } finally {
      setIsSubscribing(false);
    }
  };
  return (
    <div className="min-h-screen bg-white py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="heading-large mb-4">Adventure Travel Blog</h1>
          <p className="body-large text-[var(--text-secondary)] max-w-2xl mx-auto">
            Tips, guides, and stories from the road to help plan your next Indian adventure
          </p>
        </div>

        {/* Featured Post */}
        {blogPosts.length > 0 && (
          <div className="mb-16">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
              <div className="relative h-96 rounded-xl overflow-hidden">
                <img
                  src={blogPosts[0].image}
                  alt={blogPosts[0].title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 bg-[var(--brand-primary)] text-white text-xs font-medium rounded-full">
                    Featured
                  </span>
                </div>
              </div>
              <div>
                <div className="flex items-center space-x-2 mb-3">
                  <span className="px-3 py-1 bg-[var(--bg-light)] text-[var(--brand-primary)] text-xs font-medium rounded-full">
                    {blogPosts[0].category}
                  </span>
                </div>
                <h2 className="heading-large mb-4">{blogPosts[0].title}</h2>
                <p className="body-large text-[var(--text-secondary)] mb-6">
                  {blogPosts[0].excerpt}
                </p>
                <div className="flex items-center space-x-6 mb-6">
                  <div className="flex items-center space-x-2 text-[var(--text-secondary)]">
                    <User size={16} />
                    <span className="body-small">{blogPosts[0].author}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-[var(--text-secondary)]">
                    <Calendar size={16} />
                    <span className="body-small">{blogPosts[0].date}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-[var(--text-secondary)]">
                    <Clock size={16} />
                    <span className="body-small">{blogPosts[0].readTime}</span>
                  </div>
                </div>
                <button className="btn-primary">Read Full Article</button>
              </div>
            </div>
          </div>
        )}

        {/* Blog Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.slice(1).map((post) => (
            <article
              key={post.id}
              className="bg-white rounded-xl overflow-hidden border border-[var(--border-medium)] hover-lift cursor-pointer"
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
                />
                <div className="absolute top-3 left-3">
                  <span className="px-2 py-1 bg-white/90 backdrop-blur-sm text-[var(--brand-primary)] text-xs font-medium rounded-full">
                    {post.category}
                  </span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="heading-medium text-base mb-3 line-clamp-2">
                  {post.title}
                </h3>
                <p className="body-small text-[var(--text-secondary)] mb-4 line-clamp-3">
                  {post.excerpt}
                </p>
                <div className="flex items-center justify-between pt-4 border-t border-[var(--border-medium)]">
                  <div className="flex items-center space-x-2 text-[var(--text-secondary)]">
                    <User size={14} />
                    <span className="body-small">{post.author}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-[var(--text-secondary)]">
                    <Clock size={14} />
                    <span className="body-small">{post.readTime}</span>
                  </div>
                </div>
                <div className="mt-3">
                  <span className="body-small text-[var(--text-secondary)]">{post.date}</span>
                </div>
              </div>
            </article>
          ))}
        </div>

        {/* CTA Section */}
        <div className="mt-20 gradient-waitlist rounded-xl p-12 text-center">
          <h2 className="heading-large mb-4">Want Travel Tips in Your Inbox?</h2>
          <p className="body-large text-[var(--text-secondary)] mb-8 max-w-2xl mx-auto">
            Get exclusive adventure guides, hidden gems, and special offers delivered weekly
          </p>
          <form onSubmit={handleNewsletterSubmit} className="max-w-md mx-auto">
            <div className="form-with-button">
              <input
                type="email"
                value={newsletterEmail}
                onChange={(e) => setNewsletterEmail(e.target.value)}
                placeholder="Enter your email address"
                className="form-input w-full"
                disabled={isSubscribing}
              />
              <button
                type="submit"
                disabled={isSubscribing}
                className="form-submit-embedded disabled:opacity-50"
              >
                {isSubscribing ? 'Subscribing...' : 'Subscribe'}
              </button>
            </div>
          </form>
        </div>

        {/* Categories */}
        <div className="mt-20">
          <h3 className="heading-medium mb-6">Browse by Category</h3>
          <div className="flex flex-wrap gap-3">
            {['Trekking', 'Travel Tips', 'Seasonal', 'Adventure', 'Budget Travel', 'Cultural'].map((category) => (
              <button
                key={category}
                className="btn-secondary"
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Blog;
