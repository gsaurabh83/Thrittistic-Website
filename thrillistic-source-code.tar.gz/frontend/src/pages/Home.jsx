import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Star, Clock, TrendingUp, Mail } from 'lucide-react';
import { toast } from 'sonner';
import axios from 'axios';
import { heroSlides, featuredTrips, testimonials, galleryImages } from '../data/mockData';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const Home = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [showEmailPopup, setShowEmailPopup] = useState(false);
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [isSubscribing, setIsSubscribing] = useState(false);

  // Auto-advance hero slider
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  // Exit-intent email popup
  useEffect(() => {
    const handleMouseLeave = (e) => {
      if (e.clientY <= 0 && !showEmailPopup) {
        setShowEmailPopup(true);
      }
    };
    document.addEventListener('mouseleave', handleMouseLeave);
    return () => document.removeEventListener('mouseleave', handleMouseLeave);
  }, [showEmailPopup]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + heroSlides.length) % heroSlides.length);
  };

  const getDifficultyClass = (difficulty) => {
    const classes = {
      'Chill': 'difficulty-chill',
      'Easy': 'difficulty-easy',
      'Moderate': 'difficulty-moderate',
      'Hard': 'difficulty-hard',
      'Extreme': 'difficulty-extreme'
    };
    return classes[difficulty] || 'difficulty-easy';
  };

  const handleNewsletterSubmit = async (e) => {
    e.preventDefault();
    
    if (!newsletterEmail) {
      toast.error('Please enter your email address');
      return;
    }

    setIsSubscribing(true);

    try {
      const response = await axios.post(`${BACKEND_URL}/api/newsletter/subscribe`, {
        email: newsletterEmail
      });
      
      if (response.data.success) {
        toast.success(response.data.message);
        setNewsletterEmail('');
        setShowEmailPopup(false);
      }
    } catch (error) {
      console.error('Newsletter subscription error:', error);
      toast.error('Failed to subscribe. Please try again later.');
    } finally {
      setIsSubscribing(false);
    }
  };

  return (
    <div className="min-h-screen">
      {/* Hero Slider */}
      <section className="relative h-screen hero-slider-container">
        {heroSlides.map((slide, index) => (
          <div
            key={slide.id}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentSlide ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <img
              src={slide.image}
              alt={slide.title}
              className="hero-slide-image"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent" />
          </div>
        ))}

        {/* Hero Content */}
        <div className="absolute inset-0 flex items-center justify-center z-10">
          <div className="container mx-auto px-4 text-center">
            <h1 className="display-hero text-white mb-6 animate-slide-up">
              Curated Thrilling Adventures<br />Across India
            </h1>
            <p className="body-large text-white/90 mb-8 max-w-2xl mx-auto animate-slide-up delay-200">
              Adventure Redefined, Memories Guaranteed
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up delay-300">
              <Link to="/destinations" className="btn-primary hover-scale">
                Explore Trips
              </Link>
              <Link to="/contact" className="btn-primary hover-scale" style={{ background: 'rgba(255,255,255,0.2)', backdropFilter: 'blur(10px)' }}>
                Get Deals
              </Link>
            </div>
            <div className="mt-8 animate-slide-up delay-400">
              <p className="body-small text-white/80">
                {heroSlides[currentSlide].title} • {heroSlides[currentSlide].subtitle}
              </p>
            </div>
          </div>
        </div>

        {/* Slider Controls */}
        <button
          onClick={prevSlide}
          className="absolute left-4 top-1/2 -translate-y-1/2 z-20 bg-white/20 backdrop-blur-sm p-3 rounded-full hover:bg-white/30 transition-colors"
          aria-label="Previous slide"
        >
          <ChevronLeft size={24} className="text-white" />
        </button>
        <button
          onClick={nextSlide}
          className="absolute right-4 top-1/2 -translate-y-1/2 z-20 bg-white/20 backdrop-blur-sm p-3 rounded-full hover:bg-white/30 transition-colors"
          aria-label="Next slide"
        >
          <ChevronRight size={24} className="text-white" />
        </button>

        {/* Slide Indicators */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 flex space-x-2">
          {heroSlides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-2 h-2 rounded-full transition-all ${
                index === currentSlide ? 'bg-white w-8' : 'bg-white/50'
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      </section>

      {/* Featured Trips */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="heading-large mb-4">Featured Adventures</h2>
            <p className="body-large text-[var(--text-secondary)] max-w-2xl mx-auto">
              Handpicked thrilling experiences across India's most stunning landscapes
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredTrips.slice(0, 6).map((trip) => (
              <div key={trip.id} className="trip-card bg-white rounded-xl overflow-hidden border border-[var(--border-medium)]">
                <div className="relative h-64 overflow-hidden">
                  <img
                    src={trip.image}
                    alt={trip.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="image-overlay" />
                  <div className="absolute top-4 right-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${getDifficultyClass(trip.difficulty)}`}>
                      {trip.difficulty}
                    </span>
                  </div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="heading-medium text-white">{trip.name}</h3>
                  </div>
                </div>
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-2 text-[var(--text-secondary)]">
                      <Clock size={16} />
                      <span className="body-small">{trip.duration}</span>
                    </div>
                    <div className="body-standard font-semibold text-[var(--brand-primary)]">
                      {trip.price}
                    </div>
                  </div>
                  <p className="body-small text-[var(--text-secondary)] mb-4 line-clamp-2">
                    {trip.description}
                  </p>
                  <Link
                    to={`/destinations?trip=${trip.id}`}
                    className="btn-secondary w-full text-center block"
                  >
                    View Details
                  </Link>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link to="/destinations" className="btn-primary hover-scale">
              View All Destinations
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-[var(--bg-light)]">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="heading-large mb-4">What Our Travelers Say</h2>
            <p className="body-large text-[var(--text-secondary)]">
              5000+ happy travelers and counting
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial) => (
              <div key={testimonial.id} className="testimonial-card">
                <div className="flex items-center mb-4">
                  {testimonial.image ? (
                    <img
                      src={testimonial.image}
                      alt={testimonial.name}
                      className="w-12 h-12 rounded-full object-cover mr-4"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-full bg-[var(--brand-primary)] text-white flex items-center justify-center mr-4 font-semibold">
                      {testimonial.name.charAt(0)}
                    </div>
                  )}
                  <div>
                    <h4 className="body-standard font-semibold">{testimonial.name}</h4>
                    <p className="body-small text-[var(--text-secondary)]">{testimonial.location}</p>
                  </div>
                </div>
                <div className="flex mb-3">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} size={16} className="star-rating fill-current" />
                  ))}
                </div>
                <p className="body-small text-[var(--text-secondary)]">{testimonial.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Preview */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="heading-large mb-4">Adventure Gallery</h2>
            <p className="body-large text-[var(--text-secondary)]">
              Moments captured by our travelers
            </p>
          </div>

          <div className="gallery-grid">
            {galleryImages.map((image) => (
              <div key={image.id} className="relative overflow-hidden rounded-lg aspect-square hover-lift cursor-pointer group">
                <img
                  src={image.url}
                  alt={image.caption}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <p className="body-small text-white font-medium">{image.caption}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 gradient-waitlist">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="heading-large mb-4">Ready for Your Next Adventure?</h2>
          <p className="body-large text-[var(--text-secondary)] mb-8 max-w-2xl mx-auto">
            Get exclusive deals and hidden gems guide delivered to your inbox
          </p>
          <form onSubmit={handleNewsletterSubmit} className="max-w-md mx-auto">
            <div className="form-with-button">
              <input
                type="email"
                value={newsletterEmail}
                onChange={(e) => setNewsletterEmail(e.target.value)}
                placeholder="Enter your email address"
                className="form-input w-full"
                disabled={isSubscribing}
              />
              <button
                type="submit"
                disabled={isSubscribing}
                className="form-submit-embedded disabled:opacity-50"
              >
                {isSubscribing ? 'Subscribing...' : 'Subscribe'}
              </button>
            </div>
            <p className="body-small text-[var(--text-secondary)] mt-4">
              Or call us at <a href="tel:+919310191560" className="text-[var(--brand-primary)] hover:underline">+91 9310191560</a>
            </p>
          </form>
        </div>
      </section>

      {/* Email Popup */}
      {showEmailPopup && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl p-8 max-w-md w-full relative">
            <button
              onClick={() => setShowEmailPopup(false)}
              className="absolute top-4 right-4 text-[var(--text-secondary)] hover:text-[var(--text-primary)]"
              aria-label="Close"
            >
              <svg width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M6 6l12 12M6 18L18 6" />
              </svg>
            </button>
            <h3 className="heading-medium mb-4">Wait! Before You Go...</h3>
            <p className="body-standard text-[var(--text-secondary)] mb-6">
              Get exclusive deals + hidden gems guide for your next Indian adventure
            </p>
            <form onSubmit={handleNewsletterSubmit} className="space-y-4">
              <input
                type="email"
                value={newsletterEmail}
                onChange={(e) => setNewsletterEmail(e.target.value)}
                placeholder="Enter your email"
                className="form-input w-full"
                disabled={isSubscribing}
              />
              <button
                type="submit"
                disabled={isSubscribing}
                className="btn-primary w-full disabled:opacity-50"
              >
                {isSubscribing ? 'Subscribing...' : 'Get My Free Guide'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Home;
