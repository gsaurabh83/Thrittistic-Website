import React, { useState } from 'react';
import { Star, Award, Shield, Users, TrendingUp, CheckCircle } from 'lucide-react';
import { testimonials } from '../data/mockData';

const About = () => {
  const [quizStep, setQuizStep] = useState(0);
  const [quizAnswers, setQuizAnswers] = useState({});
  const [showResults, setShowResults] = useState(false);

  const quizQuestions = [
    {
      id: 1,
      question: "What's your adventure budget per person?",
      options: [
        { value: "Under 10k", label: "Under ₹10,000" },
        { value: "10-25k", label: "₹10,000 - ₹25,000" },
        { value: "25k+", label: "₹25,000+" }
      ]
    },
    {
      id: 2,
      question: "What's your preferred adventure level?",
      options: [
        { value: "Chill", label: "Chill & Relaxing" },
        { value: "Moderate", label: "Moderate Adventure" },
        { value: "Extreme", label: "Extreme Thrill" }
      ]
    },
    {
      id: 3,
      question: "Which region interests you most?",
      options: [
        { value: "North", label: "North (Himalayas, Kashmir)" },
        { value: "South", label: "South (Kerala, Andaman)" },
        { value: "East", label: "East (Northeast, Odisha)" },
        { value: "West", label: "West (Rajasthan, Goa)" }
      ]
    }
  ];

  const handleQuizAnswer = (questionId, value) => {
    setQuizAnswers({ ...quizAnswers, [questionId]: value });
    if (quizStep < quizQuestions.length - 1) {
      setQuizStep(quizStep + 1);
    } else {
      setShowResults(true);
    }
  };

  const resetQuiz = () => {
    setQuizStep(0);
    setQuizAnswers({});
    setShowResults(false);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative py-20 bg-[var(--bg-light)]">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="heading-large mb-6">About Thrillistic</h1>
            <p className="body-large text-[var(--text-secondary)]">
              Crafting adrenaline-pumping, safe, and authentic Indian adventures for modern explorers since 2014
            </p>
          </div>
        </div>
      </section>

      {/* Mission & Values */}
      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-20">
            <div>
              <h2 className="heading-large mb-6">Our Mission</h2>
              <p className="body-large text-[var(--text-secondary)] mb-6">
                At Thrillistic, we believe adventure is not just about reaching destinations—it's about transforming perspectives. We curate experiences that push boundaries while ensuring safety, authenticity, and unforgettable memories.
              </p>
              <p className="body-standard text-[var(--text-secondary)]">
                From the snow-capped Himalayas to tropical Andaman beaches, from spiritual Varanasi to vibrant Rajasthan, we handcraft every journey with passion and expertise.
              </p>
            </div>
            <div>
              <img
                src="https://images.unsplash.com/photo-1578592391689-0e3d1a1b52b9?crop=entropy&cs=srgb&fm=jpg&q=85"
                alt="Team adventure"
                className="rounded-xl shadow-lg w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Core Values */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-[var(--bg-light)] flex items-center justify-center">
                <Shield className="text-[var(--brand-primary)]" size={32} />
              </div>
              <h3 className="heading-medium text-base mb-2">Safety First</h3>
              <p className="body-small text-[var(--text-secondary)]">
                100% insured trips with certified guides and 24/7 emergency support
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-[var(--bg-light)] flex items-center justify-center">
                <Award className="text-[var(--brand-primary)]" size={32} />
              </div>
              <h3 className="heading-medium text-base mb-2">Expert Guides</h3>
              <p className="body-small text-[var(--text-secondary)]">
                Local experts with 10+ years of adventure travel experience
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-[var(--bg-light)] flex items-center justify-center">
                <Users className="text-[var(--brand-primary)]" size={32} />
              </div>
              <h3 className="heading-medium text-base mb-2">Small Groups</h3>
              <p className="body-small text-[var(--text-secondary)]">
                Intimate group sizes for personalized attention and connection
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-[var(--bg-light)] flex items-center justify-center">
                <CheckCircle className="text-[var(--brand-primary)]" size={32} />
              </div>
              <h3 className="heading-medium text-base mb-2">Authenticity</h3>
              <p className="body-small text-[var(--text-secondary)]">
                Real local experiences, not touristy packages
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Founder Story */}
      <section className="py-20 bg-[var(--bg-light)]">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="flex flex-col md:flex-row gap-8 items-center">
              <div className="md:w-1/3">
                <img
                  src="https://images.unsplash.com/photo-1671450960874-0903baf942c5?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjAzMzJ8MHwxfHNlYXJjaHwyfHxJbmRpYW4lMjBidXNpbmVzcyUyMHByb2Zlc3Npb25hbCUyMHBvcnRyYWl0JTIwaGVhZHNob3R8ZW58MHx8fHwxNzcwNjMxNTg2fDA&ixlib=rb-4.1.0&q=85"
                  alt="Ajit Vishwanath - Founder"
                  className="rounded-xl shadow-lg w-full aspect-square object-cover"
                />
              </div>
              <div className="md:w-2/3">
                <h2 className="heading-large mb-4">Meet Ajit Vishwanath</h2>
                <p className="body-standard text-[var(--text-secondary)] mb-4">
                  Founder & Chief Adventure Officer
                </p>
                <p className="body-standard text-[var(--text-secondary)] mb-4">
                  With over a decade of exploring India's most thrilling destinations, Ajit started Thrillistic with a simple vision: to make adventure travel accessible, safe, and unforgettable for everyone.
                </p>
                <p className="body-standard text-[var(--text-secondary)] mb-4">
                  From solo trekking in the Himalayas to leading group expeditions across 28 Indian states, Ajit's passion for adventure and deep knowledge of India's hidden gems is the heartbeat of Thrillistic.
                </p>
                <div className="flex space-x-4">
                  <a
                    href="https://www.youtube.com/@ajitvishwanath"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-secondary"
                  >
                    Watch Adventures
                  </a>
                  <a
                    href="https://www.instagram.com/ajitvishwanath"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-secondary"
                  >
                    Follow Journey
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="heading-large mb-4">Travelers Love Us</h2>
            <p className="body-large text-[var(--text-secondary)]">
              Join 5000+ happy adventurers
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial) => (
              <div key={testimonial.id} className="testimonial-card">
                <div className="flex items-center mb-4">
                  {testimonial.image ? (
                    <img
                      src={testimonial.image}
                      alt={testimonial.name}
                      className="w-12 h-12 rounded-full object-cover mr-4"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-full bg-[var(--brand-primary)] text-white flex items-center justify-center mr-4 font-semibold">
                      {testimonial.name.charAt(0)}
                    </div>
                  )}
                  <div>
                    <h4 className="body-standard font-semibold">{testimonial.name}</h4>
                    <p className="body-small text-[var(--text-secondary)]">{testimonial.location}</p>
                  </div>
                </div>
                <div className="flex mb-3">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} size={16} className="star-rating fill-current" />
                  ))}
                </div>
                <p className="body-small text-[var(--text-secondary)]">{testimonial.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Quiz Section */}
      <section className="py-20 bg-[var(--bg-light)]">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mx-auto">
            <div className="text-center mb-8">
              <h2 className="heading-large mb-4">Find Your Perfect Adventure</h2>
              <p className="body-standard text-[var(--text-secondary)]">
                Answer 3 quick questions to get personalized trip recommendations
              </p>
            </div>

            {!showResults ? (
              <div className="bg-white rounded-xl p-8 shadow-lg">
                {/* Progress Bar */}
                <div className="quiz-progress mb-8">
                  <div 
                    className="quiz-progress-fill"
                    style={{ width: `${((quizStep + 1) / quizQuestions.length) * 100}%` }}
                  />
                </div>

                {/* Question */}
                <h3 className="heading-medium mb-6">
                  {quizQuestions[quizStep].question}
                </h3>

                {/* Options */}
                <div className="space-y-3">
                  {quizQuestions[quizStep].options.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => handleQuizAnswer(quizQuestions[quizStep].id, option.value)}
                      className="w-full p-4 text-left border-2 border-[var(--border-medium)] rounded-lg hover:border-[var(--brand-primary)] transition-colors"
                    >
                      <span className="body-standard">{option.label}</span>
                    </button>
                  ))}
                </div>

                {/* Step Indicator */}
                <p className="body-small text-[var(--text-secondary)] text-center mt-6">
                  Question {quizStep + 1} of {quizQuestions.length}
                </p>
              </div>
            ) : (
              <div className="bg-white rounded-xl p-8 shadow-lg text-center">
                <h3 className="heading-medium mb-4">Perfect Matches Found!</h3>
                <p className="body-standard text-[var(--text-secondary)] mb-6">
                  Based on your preferences, we recommend checking out our Ladakh, Kashmir, and Rajasthan adventures.
                </p>
                <div className="flex flex-col sm:flex-row gap-3 justify-center">
                  <a href="/destinations" className="btn-primary">
                    View Recommendations
                  </a>
                  <button onClick={resetQuiz} className="btn-secondary">
                    Retake Quiz
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Trust Signals */}
      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="heading-large text-[var(--brand-primary)] mb-2">10+</div>
              <div className="body-standard text-[var(--text-secondary)]">Years Experience</div>
            </div>
            <div className="text-center">
              <div className="heading-large text-[var(--brand-primary)] mb-2">5000+</div>
              <div className="body-standard text-[var(--text-secondary)]">Happy Travelers</div>
            </div>
            <div className="text-center">
              <div className="heading-large text-[var(--brand-primary)] mb-2">50+</div>
              <div className="body-standard text-[var(--text-secondary)]">Destinations</div>
            </div>
            <div className="text-center">
              <div className="heading-large text-[var(--brand-primary)] mb-2">100%</div>
              <div className="body-standard text-[var(--text-secondary)]">Fully Insured</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
