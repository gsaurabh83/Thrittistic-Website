// Mock data for Thrillistic Travel Website

export const heroSlides = [
  {
    id: 1,
    image: "https://images.unsplash.com/photo-1762707232257-ab6057b4128b?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjAzNDR8MHwxfHNlYXJjaHwxfHxMYWRha2glMjBtb3RvcmN5Y2xlJTIwYWR2ZW50dXJlfGVufDB8fHx8MTc3MDYyOTQxN3ww&ixlib=rb-4.1.0&q=85",
    title: "Ladakh Motorcycle Odyssey",
    subtitle: "Ride Through the Himalayas"
  },
  {
    id: 2,
    image: "https://images.unsplash.com/photo-1715230656262-9410dfbead2a?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjAzMzJ8MHwxfHNlYXJjaHwxfHxSaXNoaWtlc2glMjByaXZlciUyMHJhZnRpbmd8ZW58MHx8fHwxNzcwNjI5NDI5fDA&ixlib=rb-4.1.0&q=85",
    title: "Rishikesh Rapids Adventure",
    subtitle: "Conquer the Sacred Ganges"
  },
  {
    id: 3,
    image: "https://images.unsplash.com/photo-1666955478875-1cb7ca4ca37c?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjAzMzl8MHwxfHNlYXJjaHwxfHxjYW1lbCUyMHNhZmFyaSUyMGRlc2VydHxlbnwwfHx8fDE3NzA2Mjk1NzF8MA&ixlib=rb-4.1.0&q=85",
    title: "Rajasthan Desert Safari",
    subtitle: "Experience Royal Heritage"
  },
  {
    id: 4,
    image: "https://images.unsplash.com/photo-1624253955293-81061e245a84?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjAzMjd8MHwxfHNlYXJjaHwxfHxLYXNobWlyJTIwdmFsbGV5JTIwbW91bnRhaW5zfGVufDB8fHx8MTc3MDYyOTQ4OXww&ixlib=rb-4.1.0&q=85",
    title: "Kashmir Valley Exploration",
    subtitle: "Paradise on Earth"
  },
  {
    id: 5,
    image: "https://images.unsplash.com/photo-1643400811590-adfc89411a30?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NTYxOTF8MHwxfHNlYXJjaHwxfHx0cm9waWNhbCUyMGJlYWNoJTIwc25vcmtlbGluZ3xlbnwwfHx8fDE3NzA2Mjk0NDh8MA&ixlib=rb-4.1.0&q=85",
    title: "Andaman Underwater World",
    subtitle: "Dive into Crystal Waters"
  },
  {
    id: 6,
    image: "https://images.unsplash.com/photo-1610701288758-dc024b74897b?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA2ODl8MHwxfHNlYXJjaHwxfHxOb3J0aGVhc3QlMjBJbmRpYSUyMHdhdGVyZmFsbHN8ZW58MHx8fHwxNzcwNjI5NTYxfDA&ixlib=rb-4.1.0&q=85",
    title: "Northeast Hidden Gems",
    subtitle: "Explore Meghalaya's Beauty"
  },
  {
    id: 7,
    image: "https://images.unsplash.com/photo-1528034342377-c406327f14b7?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjY2NzF8MHwxfHNlYXJjaHwyfHxLZXJhbGElMjBiYWNrd2F0ZXJzJTIwaG91c2Vib2F0c3xlbnwwfHx8fDE3NzA2Mjk1MDl8MA&ixlib=rb-4.1.0&q=85",
    title: "Kerala Backwaters Serenity",
    subtitle: "Float Through Paradise"
  },
  {
    id: 8,
    image: "https://images.unsplash.com/photo-1704872833058-1948ac9230c1?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDQ2NDF8MHwxfHNlYXJjaHwxfHxWYXJhbmFzaSUyMHRlbXBsZSUyMEdhbmdlc3xlbnwwfHx8fDE3NzA2Mjk0OTh8MA&ixlib=rb-4.1.0&q=85",
    title: "Kashi Spiritual Journey",
    subtitle: "Ancient City of Light"
  }
];

export const featuredTrips = [
  {
    id: 1,
    name: "Ladakh Motorcycle Odyssey",
    image: "https://images.unsplash.com/photo-1768410318044-8a43bf8fdb2c?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjAzNDR8MHwxfHNlYXJjaHwyfHxMYWRha2glMjBtb3RvcmN5Y2xlJTIwYWR2ZW50dXJlfGVufDB8fHx8MTc3MDYyOTQxN3ww&ixlib=rb-4.1.0&q=85",
    duration: "8 Days / 7 Nights",
    price: "₹45,000 - ₹55,000",
    difficulty: "Extreme",
    region: "North",
    budget: "25k+",
    season: "June - September",
    description: "Epic motorcycle journey through world's highest motorable passes including Khardung La and Chang La.",
    itinerary: [
      "Day 1: Arrival in Leh, acclimatization",
      "Day 2: Leh to Nubra Valley via Khardung La (18,380 ft)",
      "Day 3: Nubra Valley exploration, sand dunes",
      "Day 4: Nubra to Pangong via Shyok route",
      "Day 5: Pangong Lake to Leh",
      "Day 6: Leh to Tso Moriri Lake",
      "Day 7: Tso Moriri exploration and return to Leh",
      "Day 8: Departure from Leh"
    ],
    inclusions: "Royal Enfield bikes, permits, fuel, accommodation, meals, guide, backup vehicle, first aid"
  },
  {
    id: 2,
    name: "Rishikesh White Water Rafting",
    image: "https://images.unsplash.com/photo-1671506320551-49cba39dfb7b?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjAzMzJ8MHwxfHNlYXJjaHwyfHxSaXNoaWtlc2glMjByaXZlciUyMHJhZnRpbmd8ZW58MHx8fHwxNzcwNjI5NDI5fDA&ixlib=rb-4.1.0&q=85",
    duration: "3 Days / 2 Nights",
    price: "₹8,000 - ₹12,000",
    difficulty: "Moderate",
    region: "North",
    budget: "10-25k",
    season: "March - June, September - November",
    description: "Thrilling river rafting through Grade III-IV rapids with camping by the Ganges.",
    itinerary: [
      "Day 1: Arrival in Rishikesh, beach camping setup, evening bonfire",
      "Day 2: 16 km white water rafting (Shivpuri to Rishikesh), cliff jumping, body surfing",
      "Day 3: Bungee jumping, flying fox, sunrise yoga, departure"
    ],
    inclusions: "Rafting gear, camping tents, meals, guides, safety equipment, permits, adventure activities"
  },
  {
    id: 3,
    name: "Rajasthan Royal Circuit",
    image: "https://images.unsplash.com/photo-1607922276202-5007ffe552ca?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjAzMzl8MHwxfHNlYXJjaHwzfHxjYW1lbCUyMHNhZmFyaSUyMGRlc2VydHxlbnwwfHx8fDE3NzA2Mjk1NzF8MA&ixlib=rb-4.1.0&q=85",
    duration: "7 Days / 6 Nights",
    price: "₹35,000 - ₹45,000",
    difficulty: "Easy",
    region: "West",
    budget: "25k+",
    season: "October - March",
    description: "Desert safari through Jaisalmer dunes with royal palace stays in Udaipur and Jaipur.",
    itinerary: [
      "Day 1: Arrival in Jaipur, Amber Fort, City Palace",
      "Day 2: Jaipur to Pushkar, Brahma Temple, Pushkar Lake",
      "Day 3: Pushkar to Jodhpur, Mehrangarh Fort",
      "Day 4: Jodhpur to Jaisalmer, evening at Patwon Ki Haveli",
      "Day 5: Sam Sand Dunes camel safari, desert camping with cultural show",
      "Day 6: Jaisalmer Fort, drive to Udaipur",
      "Day 7: Lake Pichola boat ride, City Palace, departure"
    ],
    inclusions: "Heritage hotels, camel safari, meals, guide, transport, fort tickets, cultural shows"
  },
  {
    id: 4,
    name: "Kashmir Paradise Retreat",
    image: "https://images.unsplash.com/photo-1627894485200-b92fb4353967?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjAzMjd8MHwxfHNlYXJjaHwzfHxLYXNobWlyJTIwdmFsbGV5JTIwbW91bnRhaW5zfGVufDB8fHx8MTc3MDYyOTQ4OXww&ixlib=rb-4.1.0&q=85",
    duration: "6 Days / 5 Nights",
    price: "₹28,000 - ₹35,000",
    difficulty: "Easy",
    region: "North",
    budget: "25k+",
    season: "April - October",
    description: "Explore Srinagar's Dal Lake, Gulmarg skiing, and Pahalgam meadows in the lap of Himalayas.",
    itinerary: [
      "Day 1: Arrival in Srinagar, Shikara ride on Dal Lake, houseboat stay",
      "Day 2: Srinagar to Gulmarg, Gondola ride (world's 2nd highest cable car)",
      "Day 3: Gulmarg skiing/trekking, return to Srinagar",
      "Day 4: Srinagar to Pahalgam via saffron fields, Betaab Valley",
      "Day 5: Aru Valley and Baisaran meadows exploration",
      "Day 6: Pahalgam to Srinagar, Mughal Gardens, departure"
    ],
    inclusions: "Houseboat and hotel stays, Shikara rides, Gondola tickets, meals, guide, transport"
  },
  {
    id: 5,
    name: "Andaman Tropical Paradise",
    image: "https://images.unsplash.com/photo-1643400812819-80823d1357f6?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NTYxOTF8MHwxfHNlYXJjaHwyfHx0cm9waWNhbCUyMGJlYWNoJTIwc25vcmtlbGluZ3xlbnwwfHx8fDE3NzA2Mjk0NDh8MA&ixlib=rb-4.1.0&q=85",
    duration: "5 Days / 4 Nights",
    price: "₹32,000 - ₹40,000",
    difficulty: "Moderate",
    region: "South",
    budget: "25k+",
    season: "October - May",
    description: "Snorkeling, scuba diving, and beach hopping in crystal clear turquoise waters of Andaman Islands.",
    itinerary: [
      "Day 1: Port Blair arrival, Cellular Jail light & sound show",
      "Day 2: Ferry to Havelock Island, Radhanagar Beach sunset",
      "Day 3: Scuba diving at Elephant Beach, snorkeling",
      "Day 4: Sea walk, kayaking through mangroves",
      "Day 5: Return to Port Blair, Ross Island, departure"
    ],
    inclusions: "Inter-island ferries, beach resort stays, scuba diving, snorkeling gear, meals, guide"
  },
  {
    id: 6,
    name: "Meghalaya Living Root Bridges Trek",
    image: "https://images.unsplash.com/photo-1718791206295-e184da20df06?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA2ODl8MHwxfHNlYXJjaHwzfHxOb3J0aGVhc3QlMjBJbmRpYSUyMHdhdGVyZmFsbHN8ZW58MHx8fHwxNzcwNjI5NTYxfDA&ixlib=rb-4.1.0&q=85",
    duration: "5 Days / 4 Nights",
    price: "₹18,000 - ₹24,000",
    difficulty: "Hard",
    region: "East",
    budget: "10-25k",
    season: "October - May",
    description: "Trek to UNESCO-worthy living root bridges, Asia's wettest place Cherrapunji, and pristine waterfalls.",
    itinerary: [
      "Day 1: Guwahati to Shillong, Elephant Falls, local market",
      "Day 2: Shillong to Cherrapunji, Nohkalikai Falls, Seven Sisters Falls",
      "Day 3: Trek to Double Decker Living Root Bridge (3000 steps)",
      "Day 4: Mawlynnong (Asia's cleanest village), Dawki crystal river",
      "Day 5: Return to Guwahati via Umiam Lake, departure"
    ],
    inclusions: "Homestays, trekking guide, meals, transport, permits, porter service"
  },
  {
    id: 7,
    name: "Kerala Backwaters & Munnar",
    image: "https://images.unsplash.com/photo-1707893013488-51672ef83425?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjY2NzF8MHwxfHNlYXJjaHwzfHxLZXJhbGElMjBiYWNrd2F0ZXJzJTIwaG91c2Vib2F0c3xlbnwwfHx8fDE3NzA2Mjk1MDl8MA&ixlib=rb-4.1.0&q=85",
    duration: "6 Days / 5 Nights",
    price: "₹25,000 - ₹32,000",
    difficulty: "Chill",
    region: "South",
    budget: "25k+",
    season: "September - March",
    description: "Relax on luxury houseboats through Alleppey backwaters and explore Munnar tea plantations.",
    itinerary: [
      "Day 1: Cochin arrival, Fort Kochi heritage walk, Kathakali dance show",
      "Day 2: Cochin to Munnar, tea plantation visit, Mattupetty Dam",
      "Day 3: Munnar tea factory tour, Eravikulam National Park",
      "Day 4: Munnar to Thekkady, spice plantation, elephant ride",
      "Day 5: Thekkady to Alleppey, luxury houseboat check-in, backwater cruise",
      "Day 6: Houseboat breakfast, Cochin departure"
    ],
    inclusions: "Luxury houseboat, hill station hotels, meals, guide, transport, activity tickets"
  },
  {
    id: 8,
    name: "Kashi Spiritual Sojourn",
    image: "https://images.unsplash.com/photo-1757693352758-0befb901d243?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDQ2NDF8MHwxfHNlYXJjaHw0fHxWYXJhbmFzaSUyMHRlbXBsZSUyMEdhbmdlc3xlbnwwfHx8fDE3NzA2Mjk0OTh8MA&ixlib=rb-4.1.0&q=85",
    duration: "4 Days / 3 Nights",
    price: "₹12,000 - ₹18,000",
    difficulty: "Easy",
    region: "North",
    budget: "10-25k",
    season: "October - March",
    description: "Witness ancient Ganga Aarti, explore 3000+ temples, and experience India's spiritual heart.",
    itinerary: [
      "Day 1: Varanasi arrival, Sarnath Buddhist temple, evening Dashashwamedh Ghat Aarti",
      "Day 2: Sunrise boat ride on Ganges, Kashi Vishwanath Temple, narrow lanes walk",
      "Day 3: Ramnagar Fort, Tulsi Manas Temple, Ganga Aarti participation",
      "Day 4: Early morning temple visits, silk weaving workshop, departure"
    ],
    inclusions: "Heritage hotel, boat rides, temple guide, meals, transport, Aarti arrangements"
  },
  {
    id: 9,
    name: "Manali Adventure Week",
    image: "https://images.unsplash.com/photo-1704393052576-273c2279f004?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NTYxODd8MHwxfHNlYXJjaHwyfHxIaW1hbGF5YW4lMjBtb3VudGFpbiUyMHRyZWtraW5nfGVufDB8fHx8MTc3MDYyOTU4M3ww&ixlib=rb-4.1.0&q=85",
    duration: "7 Days / 6 Nights",
    price: "₹22,000 - ₹28,000",
    difficulty: "Moderate",
    region: "North",
    budget: "10-25k",
    season: "March - June, September - November",
    description: "Paragliding in Solang Valley, river rafting, trekking to Hampta Pass, and Rohtang adventures.",
    itinerary: [
      "Day 1: Delhi to Manali overnight journey",
      "Day 2: Arrival, Hadimba Temple, Old Manali exploration",
      "Day 3: Solang Valley paragliding, zorbing, quad biking",
      "Day 4: Rohtang Pass excursion (snow activities)",
      "Day 5: Kullu river rafting, local market",
      "Day 6: Trek to Jogini Falls, hot springs visit",
      "Day 7: Return journey to Delhi"
    ],
    inclusions: "Volvo transport, hotels, meals, adventure activities, guide, permits"
  },
  {
    id: 10,
    name: "Goa Beach & Party Escape",
    image: "https://images.unsplash.com/photo-1528543606781-2f6e6857f318?crop=entropy&cs=srgb&fm=jpg&q=85",
    duration: "5 Days / 4 Nights",
    price: "₹15,000 - ₹22,000",
    difficulty: "Chill",
    region: "West",
    budget: "10-25k",
    season: "November - February",
    description: "Beaches, water sports, nightlife, Portuguese heritage, and seafood feast in India's party capital.",
    itinerary: [
      "Day 1: Arrival, check-in to beach resort, Baga Beach sunset",
      "Day 2: Water sports (jet ski, parasailing, banana boat), beach shacks",
      "Day 3: Old Goa churches, Fort Aguada, Anjuna Flea Market",
      "Day 4: Scuba diving, Dudhsagar Falls excursion",
      "Day 5: Beach hopping (Palolem, Agonda), departure"
    ],
    inclusions: "Beach resort, meals, water sports, scuba diving, transport, club entry passes"
  },
  {
    id: 11,
    name: "Spiti Valley Wilderness",
    image: "https://images.unsplash.com/photo-1704393052379-0b020d30e8ee?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NTYxODd8MHwxfHNlYXJjaHwxfHxIaW1hbGF5YW4lMjBtb3VudGFpbiUyMHRyZWtraW5nfGVufDB8fHx8MTc3MDYyOTU4M3ww&ixlib=rb-4.1.0&q=85",
    duration: "10 Days / 9 Nights",
    price: "₹38,000 - ₹48,000",
    difficulty: "Extreme",
    region: "North",
    budget: "25k+",
    season: "May - September",
    description: "Remote Himalayan valley expedition to ancient monasteries, high-altitude villages, and moonscapes.",
    itinerary: [
      "Day 1-2: Manali to Kaza via Kunzum Pass, acclimatization",
      "Day 3: Key Monastery, Kibber village (world's highest motorable village)",
      "Day 4: Chandratal Lake camping",
      "Day 5-6: Tabo Monastery, Pin Valley National Park (snow leopard habitat)",
      "Day 7: Dhankar Monastery cliff hanging village",
      "Day 8: Langza fossil village, Comic village",
      "Day 9-10: Return journey via Kalpa, Chitkul"
    ],
    inclusions: "4WD vehicles, homestays, camping, meals, permits, guide, oxygen cylinders, first aid"
  },
  {
    id: 12,
    name: "Hampi Heritage Cycling",
    image: "https://images.unsplash.com/photo-1641838013012-29b225f2a2f6?crop=entropy&cs=srgb&fm=jpg&q=85",
    duration: "4 Days / 3 Nights",
    price: "₹10,000 - ₹15,000",
    difficulty: "Easy",
    region: "South",
    budget: "Under 10k",
    season: "October - March",
    description: "Cycle through UNESCO World Heritage ruins, boulder landscapes, and Vijayanagara Empire history.",
    itinerary: [
      "Day 1: Hospet arrival, Hampi exploration, sunset at Hemakuta Hill",
      "Day 2: Cycling tour to Vittala Temple (stone chariot), musical pillars",
      "Day 3: Cycling to Anegundi village, coracle ride, Anjaneya Hill climb",
      "Day 4: Virupaksha Temple, Royal Enclosure, Queen's Bath, departure"
    ],
    inclusions: "Guesthouse, bicycles, guide, meals, monument tickets, coracle ride"
  }
];

export const testimonials = [
  {
    id: 1,
    name: "Priya Sharma",
    location: "Mumbai",
    image: "", // No image - text only testimonial
    rating: 5,
    text: "Best trip ever! Ladakh motorcycle odyssey was life-changing. The guides were professional, safety was top priority, and the experience exceeded all expectations."
  },
  {
    id: 2,
    name: "Rahul Verma",
    location: "Delhi",
    image: "", // No image - text only testimonial
    rating: 5,
    text: "Thrillistic made our Rishikesh rafting adventure unforgettable! Perfect organization, amazing team, and memories that will last forever."
  },
  {
    id: 3,
    name: "Ananya Patel",
    location: "Bangalore",
    image: "", // No image - text only testimonial
    rating: 5,
    text: "Kashmir trip was pure magic! From Dal Lake houseboats to Gulmarg snow, everything was perfectly planned. Highly recommend Thrillistic!"
  },
  {
    id: 4,
    name: "Vikram Singh",
    location: "Jaipur",
    image: "", // No image - text only testimonial
    rating: 5,
    text: "The Rajasthan Royal Circuit exceeded expectations. Heritage hotels, desert camping, and cultural experiences were authentic and thrilling!"
  },
  {
    id: 5,
    name: "Sneha Reddy",
    location: "Hyderabad",
    image: "", // No image - text only testimonial
    rating: 5,
    text: "Andaman scuba diving was a dream come true! Crystal clear waters, professional instructors, and the most beautiful beaches I've ever seen."
  }
];

export const blogPosts = [
  {
    id: 1,
    title: "Top 5 Hidden Himalayan Treks 2026",
    excerpt: "Discover lesser-known trekking routes in the Himalayas that offer stunning views without the crowds. From Hampta Pass to Valley of Flowers.",
    image: "https://images.unsplash.com/photo-1740217078286-f5b681dc7fa1?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NTYxODd8MHwxfHNlYXJjaHw0fHxIaW1hbGF5YW4lMjBtb3VudGFpbiUyMHRyZWtraW5nfGVufDB8fHx8MTc3MDYyOTU4M3ww&ixlib=rb-4.1.0&q=85",
    author: "Ajit Vishwanath",
    readTime: "5 min read",
    date: "Dec 5, 2025",
    category: "Trekking"
  },
  {
    id: 2,
    title: "Budget Rajasthan Road Trip Guide",
    excerpt: "Complete guide to exploring Rajasthan on a budget. Where to stay, eat, and the best heritage sites to visit without breaking the bank.",
    image: "https://images.unsplash.com/photo-1591018018950-798790d9f695?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjAzMzJ8MHwxfHNlYXJjaHwxfHxSYWphc3RoYW4lMjBkZXNlcnQlMjBhZHZlbnR1cmV8ZW58MHx8fHwxNzcwNjI5NDM4fDA&ixlib=rb-4.1.0&q=85",
    author: "Ajit Vishwanath",
    readTime: "8 min read",
    date: "Nov 28, 2025",
    category: "Travel Tips"
  },
  {
    id: 3,
    title: "Best Monsoon Adventure Spots in India",
    excerpt: "Embrace the rains! Explore India's most thrilling monsoon destinations from Meghalaya's living root bridges to Kerala's lush backwaters.",
    image: "https://images.unsplash.com/photo-1668900053088-c379837cdc5c?crop=entropy&cs=srgb&fm=jpg&q=85",
    author: "Travel Team",
    readTime: "6 min read",
    date: "Nov 20, 2025",
    category: "Seasonal"
  },
  {
    id: 4,
    title: "Ladakh Motorcycle Preparation Checklist",
    excerpt: "Everything you need to know before embarking on a Ladakh bike trip. Permits, packing list, bike preparation, and altitude tips.",
    image: "https://images.unsplash.com/photo-1768410318080-57c4426dbe25?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjAzNDR8MHwxfHNlYXJjaHwzfHxMYWRha2glMjBtb3RvcmN5Y2xlJTIwYWR2ZW50dXJlfGVufDB8fHx8MTc3MDYyOTQxN3ww&ixlib=rb-4.1.0&q=85",
    author: "Ajit Vishwanath",
    readTime: "10 min read",
    date: "Nov 15, 2025",
    category: "Adventure"
  }
];

export const galleryImages = [
  {
    id: 1,
    url: "https://images.unsplash.com/photo-1618083707368-b3823daa2726?crop=entropy&cs=srgb&fm=jpg&q=85",
    caption: "Paragliding in Himalayas"
  },
  {
    id: 2,
    url: "https://images.unsplash.com/photo-1578592391689-0e3d1a1b52b9?crop=entropy&cs=srgb&fm=jpg&q=85",
    caption: "Summit celebration"
  },
  {
    id: 3,
    url: "https://images.unsplash.com/photo-1549414279-656ada2e7d47?crop=entropy&cs=srgb&fm=jpg&q=85",
    caption: "Treehouse adventures"
  },
  {
    id: 4,
    url: "https://images.unsplash.com/photo-1597120590849-a1d5a743d155?crop=entropy&cs=srgb&fm=jpg&q=85",
    caption: "Group trekking"
  },
  {
    id: 5,
    url: "https://images.unsplash.com/photo-1648034902541-b239c599114e?crop=entropy&cs=srgb&fm=jpg&q=85",
    caption: "Mountain sunset"
  },
  {
    id: 6,
    url: "https://images.unsplash.com/photo-1664109074701-6c95090e852e?crop=entropy&cs=srgb&fm=jpg&q=85",
    caption: "Hill station mist"
  },
  {
    id: 7,
    url: "https://images.unsplash.com/photo-1666891717987-7509e81db05a?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjY2NzF8MHwxfHNlYXJjaHwxfHxNdW5uYXIlMjB0ZWElMjBwbGFudGF0aW9uc3xlbnwwfHx8fDE3NzA2Mjk1MjF8MA&ixlib=rb-4.1.0&q=85",
    caption: "Tea plantations"
  },
  {
    id: 8,
    url: "https://images.unsplash.com/photo-1720591658325-90372cc7da02?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjY2NzF8MHwxfHNlYXJjaHw0fHxNdW5uYXIlMjB0ZWElMjBwbGFudGF0aW9uc3xlbnwwfHx8fDE3NzA2Mjk1MjF8MA&ixlib=rb-4.1.0&q=85",
    caption: "Munnar roads"
  }
];

export const quizQuestions = [
  {
    id: 1,
    question: "What's your adventure budget per person?",
    options: [
      { value: "Under 10k", label: "Under ₹10,000" },
      { value: "10-25k", label: "₹10,000 - ₹25,000" },
      { value: "25k+", label: "₹25,000+" }
    ]
  },
  {
    id: 2,
    question: "What's your preferred adventure level?",
    options: [
      { value: "Chill", label: "Chill & Relaxing" },
      { value: "Moderate", label: "Moderate Adventure" },
      { value: "Extreme", label: "Extreme Thrill" }
    ]
  },
  {
    id: 3,
    question: "How many days can you travel?",
    options: [
      { value: "Weekend", label: "Weekend (2-3 days)" },
      { value: "3-7 days", label: "3-7 days" },
      { value: "7+ days", label: "Week or more (7+ days)" }
    ]
  },
  {
    id: 4,
    question: "Which region interests you most?",
    options: [
      { value: "North", label: "North (Himalayas, Kashmir)" },
      { value: "South", label: "South (Kerala, Andaman)" },
      { value: "East", label: "East (Northeast, Odisha)" },
      { value: "West", label: "West (Rajasthan, Goa)" }
    ]
  },
  {
    id: 5,
    question: "When are you planning to travel?",
    options: [
      { value: "Winter", label: "Winter (Nov-Feb)" },
      { value: "Summer", label: "Summer (Mar-Jun)" },
      { value: "Monsoon", label: "Monsoon (Jul-Sep)" },
      { value: "Autumn", label: "Autumn (Oct-Nov)" }
    ]
  }
];

export const faqs = [
  {
    id: 1,
    question: "What is your cancellation policy?",
    answer: "Full refund if cancelled 30+ days before departure, 50% refund for 15-30 days, 25% for 7-15 days. No refund for cancellations within 7 days of departure. Medical emergencies considered on case-by-case basis."
  },
  {
    id: 2,
    question: "Are your trips safe?",
    answer: "Absolutely! Safety is our top priority. All trips are fully insured, guides are certified professionals, we provide first-aid kits, conduct safety briefings, and have 24/7 emergency support. We've successfully completed 5000+ trips with zero major incidents."
  },
  {
    id: 3,
    question: "Can trips be customized?",
    answer: "Yes! We offer complete customization. You can modify itineraries, extend/reduce days, upgrade accommodations, add activities, or create entirely new routes. Contact us with your requirements for a personalized quote."
  },
  {
    id: 4,
    question: "What's included in the trip cost?",
    answer: "Standard packages include accommodation, meals (as mentioned), transport, guides, permits, and listed activities. Airfare, personal expenses, tips, and adventure activity insurance are typically not included unless specified."
  },
  {
    id: 5,
    question: "What group sizes do you operate?",
    answer: "Group sizes vary by trip type. Adventure trips: 8-15 people, Motorcycle expeditions: 6-12 riders, Trekking: 10-20 people, Luxury tours: 4-10 guests. Private group bookings available for 4+ travelers."
  },
  {
    id: 6,
    question: "Do I need special fitness for adventure trips?",
    answer: "Fitness requirements vary by difficulty level. 'Easy' trips need basic fitness, 'Moderate' require regular exercise routine, 'Hard' and 'Extreme' need excellent fitness and prior trekking/adventure experience. Detailed fitness guidelines provided for each trip."
  },
  {
    id: 7,
    question: "What if weather conditions are bad?",
    answer: "We monitor weather closely and prioritize safety. If conditions are unsafe, we'll modify itineraries, postpone activities, or offer alternative experiences. Major weather-related cancellations receive full refunds or trip rescheduling."
  }
];
