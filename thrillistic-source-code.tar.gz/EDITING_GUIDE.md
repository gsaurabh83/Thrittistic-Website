# Thrillistic Website - Editing Guide

## How to Edit Price Ranges

All trip prices are stored in `/app/frontend/src/data/mockData.js` file.

### Quick Edit Instructions:

1. **Open the file:**
   ```bash
   nano /app/frontend/src/data/mockData.js
   # or
   vi /app/frontend/src/data/mockData.js
   ```

2. **Find the trip you want to edit** in the `featuredTrips` array

3. **Edit the `price` field:**
   ```javascript
   {
     id: 1,
     name: "Ladakh Motorcycle Odyssey",
     price: "₹45,000 - ₹55,000",  // ← EDIT THIS LINE
     // ... rest of the trip data
   }
   ```

### Example: Changing Ladakh Trip Price

**Before:**
```javascript
{
  id: 1,
  name: "Ladakh Motorcycle Odyssey",
  duration: "8 Days / 7 Nights",
  price: "₹45,000 - ₹55,000",  // Old price
}
```

**After:**
```javascript
{
  id: 1,
  name: "Ladakh Motorcycle Odyssey",
  duration: "8 Days / 7 Nights",
  price: "₹50,000 - ₹60,000",  // New price
}
```

### Price Format Guidelines:
- Always use the Rupee symbol: `₹`
- Use comma separators for thousands: `45,000` not `45000`
- Use ranges for flexibility: `₹45,000 - ₹55,000`
- Keep it concise and readable

### All 12 Trips Quick Reference:

```javascript
// ID 1: Ladakh Motorcycle Odyssey
price: "₹45,000 - ₹55,000"

// ID 2: Rishikesh White Water Rafting
price: "₹8,000 - ₹12,000"

// ID 3: Rajasthan Royal Circuit
price: "₹35,000 - ₹45,000"

// ID 4: Kashmir Paradise Retreat
price: "₹28,000 - ₹35,000"

// ID 5: Andaman Tropical Paradise
price: "₹32,000 - ₹40,000"

// ID 6: Meghalaya Living Root Bridges Trek
price: "₹18,000 - ₹24,000"

// ID 7: Kerala Backwaters & Munnar
price: "₹25,000 - ₹32,000"

// ID 8: Kashi Spiritual Sojourn
price: "₹12,000 - ₹18,000"

// ID 9: Manali Adventure Week
price: "₹22,000 - ₹28,000"

// ID 10: Goa Beach & Party Escape
price: "₹15,000 - ₹22,000"

// ID 11: Spiti Valley Wilderness
price: "₹38,000 - ₹48,000"

// ID 12: Hampi Heritage Cycling
price: "₹10,000 - ₹15,000"
```

## Other Editable Content

### Contact Information
Look for these constants in `mockData.js` or component files:

**Phone:** `+91 9310191560` - Search in files:
- `/app/frontend/src/components/Header.jsx`
- `/app/frontend/src/components/Footer.jsx`
- `/app/frontend/src/pages/Contact.jsx`

**Email:** `ajit.vishu@gmail.com` - Same files as above

**Social Media Links:**
- Instagram: `https://www.instagram.com/thrillistictravelsdelhi`
- Instagram Personal: `https://www.instagram.com/ajitvishwanath`
- YouTube: `https://www.youtube.com/@ajitvishwanath`

### Trip Details
Each trip in `featuredTrips` array contains:
- `name`: Trip name
- `duration`: "X Days / Y Nights"
- `price`: Price range
- `difficulty`: Chill, Easy, Moderate, Hard, Extreme
- `region`: North, South, East, West
- `budget`: "Under 10k", "10-25k", "25k+"
- `season`: Best time to visit
- `description`: Short description
- `itinerary`: Array of day-by-day activities
- `inclusions`: What's included in the package

### Testimonials
Edit customer reviews in the `testimonials` array:
```javascript
{
  id: 1,
  name: "Customer Name",
  location: "City Name",
  image: "",  // Leave empty for initial avatar
  rating: 5,  // 1-5 stars
  text: "Review text here"
}
```

### Blog Posts
Edit in `blogPosts` array:
```javascript
{
  id: 1,
  title: "Blog Title",
  excerpt: "Short description",
  image: "image_url",
  author: "Author Name",
  readTime: "X min read",
  date: "Month DD, YYYY",
  category: "Category Name"
}
```

## After Making Changes

1. **Save the file** (Ctrl+X, then Y in nano; :wq in vi)

2. **The website will auto-reload** - Hot reload is enabled! Just refresh your browser.

3. **If changes don't appear:**
   ```bash
   # Restart the frontend server
   sudo supervisorctl restart frontend
   
   # Wait 10 seconds, then check
   tail -f /var/log/supervisor/frontend.out.log
   ```

## Tips for Editing

1. **Always keep proper JSON format** - commas, quotes, brackets
2. **Use a code editor** if possible (VS Code, Sublime Text)
3. **Test locally** before deploying
4. **Keep backups** of original mockData.js before major changes
5. **Maintain consistency** in formatting across all trips

## Common Mistakes to Avoid

❌ **Wrong:** `price: 45000 - 55000`  (Missing ₹ symbol and quotes)
✅ **Correct:** `price: "₹45,000 - ₹55,000"`

❌ **Wrong:** Missing comma after field
✅ **Correct:** Every field except the last needs a comma

❌ **Wrong:** Using single quotes for strings
✅ **Correct:** Use double quotes in JSON

## Need More Help?

- File location: `/app/frontend/src/data/mockData.js`
- Current changes take effect immediately with hot reload
- Check browser console (F12) for any errors after editing
