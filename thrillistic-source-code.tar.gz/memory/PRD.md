# Thrillistic Travel Website - Product Requirements Document

## Original Problem Statement
Create a complete, responsive single-page or multi-page website for an Indian domestic travel business called "Thrillistic" (domain: thrillistic.com). The site is informational with a strong focus on user engagement and lead generation through contact forms—no e-commerce needed.

**Target Audience**: Adventure-seeking Indians aged 25-45 looking for thrilling domestic trips

**Design Requirements**: 
- Modern, vibrant design with India's diverse landscapes
- Mobile-first approach
- Fast-loading (<3s)
- Accessibility (WCAG 2.1)
- Pastel-AI design guidelines with clean white backgrounds and strategic gradient accents

## Architecture & Technology Stack

### Frontend
- **Framework**: React 19.0.0
- **Build Tool**: Create React App with CRACO
- **Styling**: TailwindCSS with pastel-ai design system
- **UI Components**: Shadcn/UI (Radix UI primitives)
- **Routing**: React Router v7.5.1
- **Icons**: Lucide React
- **Fonts**: Inter (Google Fonts)

### Design System
- **Color Palette**: 
  - Primary: #008055 (Green for CTAs)
  - Gradients: Coral (#D98A8C), Yellow (#E1C567), Orange (#DFB573)
  - Clean white backgrounds with strategic gradient overlays
- **Typography**: Inter font family with responsive scaling
- **Button Styles**: Pill-shaped primary CTAs (26px radius), rounded secondary buttons (8px radius)

### Integration Points
- **Forms**: WhatsApp Business integration (direct message sending)
- **Google Forms**: External form link for detailed inquiries
- **Contact**: Phone (+91 9310191560), Email (ajit.vishu@gmail.com)
- **Social Media**: Instagram, YouTube links

## Core Features Implemented (Phase 1 - Frontend MVP)

### ✅ Completed Features (December 9, 2025)

#### 1. Home Page
- **Hero Slider**: Auto-playing carousel with 8 Indian adventure destinations
  - Ladakh motorcycle, Rishikesh rafting, Rajasthan desert, Kashmir valleys
  - Andaman snorkeling, Northeast waterfalls, Kerala backwaters, Kashi temples
  - 5-second auto-advance with manual controls
  - Slide indicators and navigation arrows
  
- **Featured Trips Section**: 6 trip cards with hover effects
  - Trip images, difficulty badges, pricing, duration
  - Quick "View Details" CTA
  
- **Testimonials**: 5-star reviews from real customers
  - Customer photos, names, locations
  - Star ratings display
  
- **Gallery Preview**: 8 image grid with hover effects
  - Adventure photos from travelers
  - Caption overlays
  
- **Email Popup**: Exit-intent modal for lead capture
  - "Unlock Exclusive Deals" messaging
  - Google Forms integration

#### 2. Destinations Page
- **Advanced Filtering System**:
  - Budget filters: Under ₹10k, ₹10-25k, ₹25k+
  - Difficulty levels: Chill, Easy, Moderate, Hard, Extreme
  - Duration: Weekend, 3-7 days, 7+ days
  - Regions: North, South, East, West India
  
- **12 Complete Trip Packages** with detailed information:
  - Ladakh Motorcycle Odyssey (8 days, ₹45-55k, Extreme)
  - Rishikesh White Water Rafting (3 days, ₹8-12k, Moderate)
  - Rajasthan Royal Circuit (7 days, ₹35-45k, Easy)
  - Kashmir Paradise Retreat (6 days, ₹28-35k, Easy)
  - Andaman Tropical Paradise (5 days, ₹32-40k, Moderate)
  - Meghalaya Living Root Bridges Trek (5 days, ₹18-24k, Hard)
  - Kerala Backwaters & Munnar (6 days, ₹25-32k, Chill)
  - Kashi Spiritual Sojourn (4 days, ₹12-18k, Easy)
  - Manali Adventure Week (7 days, ₹22-28k, Moderate)
  - Goa Beach & Party Escape (5 days, ₹15-22k, Chill)
  - Spiti Valley Wilderness (10 days, ₹38-48k, Extreme)
  - Hampi Heritage Cycling (4 days, ₹10-15k, Easy)
  
- **Trip Detail Modal**: Shadcn dialog with:
  - Full itinerary (day-by-day breakdown)
  - Inclusions list
  - Best season recommendations
  - "Request Quote" and "WhatsApp Us" CTAs

#### 3. About Page
- **Mission Statement**: Company story and values
- **Core Values Display**: 4 pillars
  - Safety First (100% insured, 24/7 support)
  - Expert Guides (10+ years experience)
  - Small Groups (personalized attention)
  - Authenticity (real local experiences)
  
- **Founder Profile**: Ajit Vishwanath
  - Bio and credentials
  - Links to YouTube and Instagram
  
- **Interactive Quiz**: "Find Your Perfect Adventure"
  - 3-question flow with progress bar
  - Budget, adventure level, region preferences
  - Personalized trip recommendations
  
- **Trust Signals**: Statistics display
  - 10+ Years Experience
  - 5000+ Happy Travelers
  - 50+ Destinations
  - 100% Fully Insured

#### 4. Blog Page
- **Featured Post**: Large hero layout
- **Blog Grid**: 3 additional posts
  - "Top 5 Hidden Himalayan Treks 2026"
  - "Budget Rajasthan Road Trip Guide"
  - "Best Monsoon Adventure Spots in India"
  - "Ladakh Motorcycle Preparation Checklist"
- **Category Filters**: Browse by topic
- **Newsletter Signup**: Email capture CTA

#### 5. Contact Page
- **Multi-Channel Contact Form**:
  - WhatsApp integration (form submits via WhatsApp)
  - Fields: Name, Email, Phone, Travelers, Trip Interest, Message
  - Trip dropdown with all 12 destinations
  
- **Quick Contact Sidebar**:
  - Phone: +91 9310191560
  - Email: ajit.vishu@gmail.com
  - WhatsApp: Direct link
  - Office location: New Delhi
  
- **Office Hours**: Business schedule display
- **Google Maps**: Embedded Delhi location
- **FAQ Accordion**: 7 common questions
  - Cancellation policy
  - Safety measures
  - Trip customization
  - Inclusions
  - Group sizes
  - Fitness requirements
  - Weather contingencies

#### 6. Global Components
- **Sticky Header**: Transparent to opaque on scroll
  - Desktop: Full navigation + phone + CTA
  - Mobile: Hamburger menu with full-screen overlay
  
- **Footer**: 4-column layout
  - Company info with social links
  - Quick links
  - Popular destinations
  - Contact information
  - Trust signals (10+ years, 5000+ travelers, etc.)
  
- **WhatsApp Floating Button**: Fixed bottom-right
  - Green background (#25D366)
  - Hover scale animation
  - Direct link to WhatsApp Business

### Mock Data Implementation
All content stored in `/app/frontend/src/data/mockData.js`:
- 8 hero slides
- 12 featured trips with complete itineraries
- 5 testimonials
- 4 blog posts
- 8 gallery images
- 7 FAQs
- Quiz questions

### Design Adherence
✅ Following pastel-ai design guidelines:
- Clean white backgrounds (#FFFFFF)
- Brand green CTAs (#008055)
- Strategic gradient accents (coral, yellow, orange)
- Inter font family
- Pill-shaped primary buttons (26px radius)
- Responsive typography scaling
- Hover effects and micro-animations
- No dark purple/blue gradients (prohibited)
- Professional spacing system

## User Personas

### Primary: Adventure Seeker Amit (28)
- IT Professional from Mumbai
- Budget: ₹25,000-50,000 per trip
- Interests: Motorcycle trips, trekking, photography
- Pain Points: Wants authentic experiences, not touristy packages

### Secondary: Family Traveler Priya (35)
- Marketing Manager from Delhi
- Budget: ₹30,000-60,000 for family of 4
- Interests: Safe, comfortable adventures with cultural exposure
- Pain Points: Needs reliable operators with good safety records

### Tertiary: Solo Backpacker Rohan (24)
- College student/Young professional
- Budget: ₹10,000-20,000
- Interests: Budget-friendly, high-adventure experiences
- Pain Points: Looking for small group trips to meet like-minded travelers

## Phase 2 - Backend Development (NOT YET IMPLEMENTED)

### Planned Backend Features
- Contact form submission storage in MongoDB
- Admin panel for trip management
- Blog CMS for content updates
- Email marketing integration
- Booking request management system
- Customer database
- Analytics dashboard

### API Endpoints (To Be Built)
- POST /api/contact - Store contact form submissions
- GET /api/trips - Fetch all trips
- GET /api/trips/:id - Get single trip details
- POST /api/quote-request - Handle trip quote requests
- GET /api/blog - Fetch blog posts
- POST /api/newsletter - Newsletter subscription

## SEO Optimization (Planned)
- Meta tags for all pages
- Schema markup for LocalBusiness and TouristTrip
- Sitemap generation
- Alt text for all images (already implemented)
- H1-H3 heading structure (already implemented)
- Mobile-first responsive design (already implemented)

## Performance Metrics (Target)
- **Load Time**: < 3 seconds (to be measured)
- **Mobile Performance**: 90+ Lighthouse score
- **Accessibility**: WCAG 2.1 AA compliance
- **SEO**: 90+ Lighthouse score

## Next Action Items

### P0 (Critical - Before Launch)
1. Replace placeholder Google Form IDs with actual form links
2. Test WhatsApp form submission on mobile devices
3. Verify all phone numbers and email addresses
4. Test all external links (YouTube, Instagram)
5. Add real Google Analytics tracking ID (if required)
6. Performance testing and optimization
7. Cross-browser testing (Chrome, Safari, Firefox, Edge)
8. Accessibility audit

### P1 (High Priority)
1. Backend API development for form storage
2. Admin panel for trip management
3. Real blog CMS integration
4. Email automation for quote requests
5. Customer testimonial collection system

### P2 (Nice to Have)
1. Trip comparison feature
2. User accounts and saved trips
3. Photo gallery from real customer trips
4. Live chat support
5. Multi-language support (Hindi, regional languages)
6. Payment gateway integration (for deposits)
7. Itinerary PDF download feature

## Known Limitations (Phase 1 - Frontend Only)
- Forms send data via WhatsApp (no database storage)
- Blog content is static (hardcoded in mock data)
- No admin panel (all content changes require code updates)
- No user authentication
- No booking/payment system
- Google Form links are placeholders
- Analytics not yet configured

## Success Metrics (Phase 2)
- **Lead Generation**: 50+ quote requests per month
- **WhatsApp Engagement**: 100+ messages per month
- **Email Signups**: 200+ newsletter subscribers per month
- **Trip Bookings**: 10+ confirmed bookings per month
- **Average Session Duration**: > 3 minutes
- **Bounce Rate**: < 40%

## Deployment Notes
- Frontend deployed on port 3000
- Hot reload enabled for development
- Production build command: `yarn build`
- Environment variables in `/app/frontend/.env`

---

**Last Updated**: December 9, 2025
**Current Phase**: Phase 1 Complete (Frontend MVP with Mock Data)
**Next Phase**: Backend Development & Integrations

---

## Phase 2 Implementation Complete (December 9, 2025)

### Backend APIs Implemented ✅

#### 1. Contact Form API
- **Endpoint**: `POST /api/contact/submit`
- **Functionality**: Stores contact form submissions in MongoDB
- **Collections**: `contact_submissions` collection
- **Features**:
  - Form validation (Pydantic models)
  - Automatic timestamp and status tracking
  - Unique submission ID generation
  - Success/error handling with proper HTTP status codes

#### 2. Newsletter Subscription API
- **Endpoint**: `POST /api/newsletter/subscribe`
- **Functionality**: Stores email subscribers in MongoDB
- **Collections**: `newsletter_subscribers` collection
- **Features**:
  - Duplicate email detection
  - Reactivation of unsubscribed users
  - Active/inactive status management
  - Email validation

#### 3. Admin Endpoints
- **GET /api/contact/submissions**: Retrieve all contact submissions (paginated)
- **GET /api/newsletter/subscribers**: Retrieve all active subscribers (paginated)
- **GET /api/health**: Health check endpoint

### Frontend Integration ✅

#### Updated Pages:
1. **Contact Page** (`/app/frontend/src/pages/Contact.jsx`)
   - Form now submits to backend API
   - Success/error toast notifications
   - WhatsApp fallback on API failure
   - Loading states during submission
   - Form reset on successful submission

2. **Home Page** (`/app/frontend/src/pages/Home.jsx`)
   - Newsletter subscription form with API integration
   - Exit-intent popup newsletter signup
   - Real-time validation and feedback
   - Toast notifications for success/error

3. **Blog Page** (`/app/frontend/src/pages/Blog.jsx`)
   - Newsletter subscription integrated
   - Consistent UX with Home page

### Database Schema

#### contact_submissions Collection:
```json
{
  "_id": ObjectId,
  "id": "uuid-string",
  "name": "String",
  "email": "String (validated)",
  "phone": "String",
  "tripInterest": "String",
  "travelers": "String",
  "message": "String",
  "submittedAt": ISODate,
  "status": "new" | "contacted" | "converted" | "closed"
}
```

#### newsletter_subscribers Collection:
```json
{
  "_id": ObjectId,
  "id": "uuid-string",
  "email": "String (validated, unique)",
  "subscribedAt": ISODate,
  "status": "active" | "unsubscribed"
}
```

### Testing Results ✅

**Contact Form Submission:**
- ✅ Form validation working
- ✅ Data stored in MongoDB successfully
- ✅ Success toast notification displayed
- ✅ Form resets after submission
- ✅ WhatsApp fallback functional
- ✅ 2 test submissions verified in database

**Newsletter Subscription:**
- ✅ Email subscription working
- ✅ Duplicate detection working
- ✅ Success notifications functional
- ✅ 1 test subscriber verified in database

**Admin Endpoints:**
- ✅ GET submissions returning proper data
- ✅ GET subscribers returning proper data
- ✅ Pagination working correctly
- ✅ ObjectId serialization fixed

### Technical Implementation Details

**Backend:**
- FastAPI with async/await
- Motor (async MongoDB driver)
- Pydantic for data validation
- CORS enabled for frontend access
- Proper error handling and logging

**Frontend:**
- Axios for HTTP requests
- Sonner for toast notifications
- Form state management with React hooks
- Loading states and disabled buttons during submission
- Proper error handling with fallbacks

### Current Status: Phase 2 Complete

**Implemented:**
- ✅ Contact form backend API
- ✅ Newsletter subscription API
- ✅ MongoDB integration
- ✅ Frontend-backend integration
- ✅ Success/error handling
- ✅ Admin endpoints for data retrieval
- ✅ Form validation
- ✅ Toast notifications

**Working Features:**
- Users can submit contact forms and data is stored in database
- Newsletter subscriptions are tracked in database
- Admin can retrieve all submissions and subscribers via API
- Form resets automatically after successful submission
- WhatsApp fallback still available as backup option

### Next Steps (Phase 3 - Future)

**P1 - Admin Dashboard:**
- Build admin UI to view submissions
- Export data to CSV
- Email notifications on new submissions
- Status management (mark as contacted, converted, etc.)

**P2 - Email Automation:**
- Welcome email for newsletter subscribers
- Auto-responder for contact form submissions
- Weekly newsletter sending system
- Email templates for communications

**P3 - Analytics:**
- Track conversion rates
- Form abandonment tracking
- Popular trip interest analysis
- Geographic analysis of inquiries

**P4 - Enhanced Features:**
- Trip booking system with deposits
- User accounts for saving favorite trips
- Dynamic trip content management (CMS)
- Photo gallery from real customer trips

---

**Last Updated**: December 9, 2025
**Current Phase**: Phase 2 Complete (Backend + Frontend Integration)
**Next Phase**: Phase 3 (Admin Dashboard & Email Automation)
