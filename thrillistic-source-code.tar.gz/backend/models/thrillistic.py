from pydantic import BaseModel, Field, EmailStr
from typing import Optional
from datetime import datetime
from enum import Enum

class SubmissionStatus(str, Enum):
    NEW = "new"
    CONTACTED = "contacted"
    CONVERTED = "converted"
    CLOSED = "closed"

class SubscriptionStatus(str, Enum):
    ACTIVE = "active"
    UNSUBSCRIBED = "unsubscribed"

# Contact Form Submission Models
class ContactSubmissionCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    email: EmailStr
    phone: str = Field(..., min_length=10, max_length=20)
    tripInterest: str = Field(default="", max_length=200)
    travelers: str = Field(default="1")
    message: str = Field(..., min_length=10, max_length=2000)

class ContactSubmission(ContactSubmissionCreate):
    id: str = Field(default_factory=lambda: str(__import__('uuid').uuid4()))
    submittedAt: datetime = Field(default_factory=datetime.utcnow)
    status: SubmissionStatus = Field(default=SubmissionStatus.NEW)

    class Config:
        json_schema_extra = {
            "example": {
                "name": "John Doe",
                "email": "john@example.com",
                "phone": "+91 9876543210",
                "tripInterest": "Ladakh Motorcycle Odyssey",
                "travelers": "2",
                "message": "Interested in booking for March 2026"
            }
        }

# Newsletter Subscription Models
class NewsletterSubscriptionCreate(BaseModel):
    email: EmailStr

class NewsletterSubscription(NewsletterSubscriptionCreate):
    id: str = Field(default_factory=lambda: str(__import__('uuid').uuid4()))
    subscribedAt: datetime = Field(default_factory=datetime.utcnow)
    status: SubscriptionStatus = Field(default=SubscriptionStatus.ACTIVE)

    class Config:
        json_schema_extra = {
            "example": {
                "email": "subscriber@example.com"
            }
        }

# Response Models
class SuccessResponse(BaseModel):
    success: bool
    message: str
    submissionId: Optional[str] = None

class ErrorResponse(BaseModel):
    success: bool = False
    message: str
    error: Optional[str] = None
