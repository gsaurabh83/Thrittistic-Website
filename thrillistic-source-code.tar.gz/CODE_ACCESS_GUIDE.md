# Thrillistic Travel Website - Code Structure & Access Guide

## 📁 Complete File Structure

### Frontend Code (`/app/frontend/`)

#### Core Application Files
```
/app/frontend/src/
├── App.js                      # Main app component with routing
├── App.css                     # Global styles
├── index.css                   # Design system & Tailwind config
├── index.js                    # React entry point
│
├── components/
│   ├── Header.jsx              # Navigation header with mobile menu
│   ├── Footer.jsx              # Footer with links and contact info
│   ├── WhatsAppFloat.jsx       # Floating WhatsApp button
│   │
│   └── ui/                     # Shadcn UI components
│       ├── accordion.jsx
│       ├── dialog.jsx
│       ├── button.jsx
│       ├── card.jsx
│       └── ... (30+ components)
│
├── pages/
│   ├── Home.jsx                # Homepage with hero slider, featured trips
│   ├── About.jsx               # About page with quiz, founder info
│   ├── Destinations.jsx        # Destinations with filters, trip cards
│   ├── Blog.jsx                # Blog listing page
│   └── Contact.jsx             # Contact form with FAQ
│
├── data/
│   └── mockData.js             # All trip data, testimonials, blog posts
│
└── hooks/
    └── use-toast.js            # Toast notification hook
```

#### Configuration Files
```
/app/frontend/
├── package.json                # Dependencies
├── tailwind.config.js          # Tailwind configuration
├── craco.config.js            # Build configuration
├── jsconfig.json              # Path aliases
└── .env                       # Environment variables (BACKEND_URL)
```

### Backend Code (`/app/backend/`)

#### Core API Files
```
/app/backend/
├── server.py                   # Main FastAPI application
│
├── models/
│   └── thrillistic.py         # Pydantic models for validation
│
└── routes/
    └── thrillistic.py         # API endpoints (contact, newsletter)
```

#### Configuration Files
```
/app/backend/
├── requirements.txt           # Python dependencies
└── .env                      # Environment variables (MONGO_URL)
```

### Documentation Files
```
/app/
├── memory/
│   └── PRD.md                 # Product Requirements Document
│
├── EDITING_GUIDE.md           # How to edit prices & content
└── BACKEND_PLAN.md            # Backend integration plan
```

---

## 💾 How to Access the Code

### Method 1: Download from Container (Recommended)

Create a zip file of the entire project:

```bash
# From your terminal
cd /app
zip -r thrillistic-website.zip frontend backend memory EDITING_GUIDE.md BACKEND_PLAN.md \
  -x "*/node_modules/*" "*/build/*" "*/__pycache__/*" "*/.git/*"
```

Then download using your container's file manager or:

```bash
# The zip file will be at /app/thrillistic-website.zip
# Download it using your Emergent dashboard or file browser
```

### Method 2: View Individual Files

All files are located at:
- **Frontend**: `/app/frontend/`
- **Backend**: `/app/backend/`
- **Documentation**: `/app/`

You can view any file using:
```bash
cat /app/frontend/src/pages/Home.jsx
# or
nano /app/frontend/src/pages/Home.jsx
```

### Method 3: Clone to GitHub (If You Have Git Access)

```bash
cd /app
git init
git add .
git commit -m "Thrillistic travel website - complete"
git remote add origin YOUR_GITHUB_REPO_URL
git push -u origin main
```

---

## 📋 Key Files You'll Need

### 1. Frontend Entry Point
**File**: `/app/frontend/src/App.js`
- Main routing and layout structure
- Includes all pages and components

### 2. Design System
**File**: `/app/frontend/src/index.css`
- Complete pastel-ai design guidelines
- Color variables, typography, button styles
- All CSS custom properties

### 3. Mock Data (Edit Prices Here!)
**File**: `/app/frontend/src/data/mockData.js`
- All 12 trip packages with prices, itineraries
- Testimonials, blog posts, FAQs
- Easy to edit and update

### 4. Backend API
**File**: `/app/backend/server.py`
- FastAPI application
- MongoDB integration
- CORS configuration

**File**: `/app/backend/routes/thrillistic.py`
- Contact form endpoint
- Newsletter subscription endpoint
- Admin endpoints

### 5. Configuration
**Frontend Environment**: `/app/frontend/.env`
```env
REACT_APP_BACKEND_URL=your-backend-url
```

**Backend Environment**: `/app/backend/.env`
```env
MONGO_URL=your-mongodb-connection-string
DB_NAME=thrillistic_db
```

---

## 🚀 How to Run Locally

### Prerequisites
- Node.js 18+ and Yarn
- Python 3.11+
- MongoDB

### Frontend Setup
```bash
cd /app/frontend
yarn install
yarn start
# Runs on http://localhost:3000
```

### Backend Setup
```bash
cd /app/backend
pip install -r requirements.txt
uvicorn server:app --reload --host 0.0.0.0 --port 8001
# Runs on http://localhost:8001
```

---

## 📦 Dependencies

### Frontend (package.json)
```json
{
  "react": "^19.0.0",
  "react-dom": "^19.0.0",
  "react-router-dom": "^7.5.1",
  "axios": "^1.8.4",
  "lucide-react": "^0.507.0",
  "sonner": "^2.0.3",
  "@radix-ui/react-*": "Multiple Shadcn components",
  "tailwindcss": "^3.4.17"
}
```

### Backend (requirements.txt)
```txt
fastapi==0.110.1
uvicorn==0.25.0
motor==3.3.1
pydantic>=2.6.4
python-dotenv>=1.0.1
```

---

## 🎨 Design Assets

### Colors Used
- **Primary Green**: `#008055` (Brand CTAs)
- **Secondary Green**: `#0A6647` (Hover states)
- **Gradient Coral**: `#D98A8C`
- **Gradient Yellow**: `#E1C567`
- **Gradient Orange**: `#DFB573`

### Fonts
- **Primary**: Inter (Google Fonts)
- Loaded in: `/app/frontend/src/index.css`

### Images
All images are from Unsplash (high-quality, commercial-free):
- 8 hero slider images
- 12 destination images
- 8 gallery images
- Testimonial avatars (generated)

---

## 📝 Quick Customization Guide

### Change Trip Prices
Edit: `/app/frontend/src/data/mockData.js`
```javascript
{
  id: 1,
  name: "Ladakh Motorcycle Odyssey",
  price: "₹45,000 - ₹55,000"  // ← Change this
}
```

### Update Contact Info
Edit in these files:
- `/app/frontend/src/components/Header.jsx`
- `/app/frontend/src/components/Footer.jsx`
- `/app/frontend/src/pages/Contact.jsx`

Search for: `+91 9310191560` or `ajit.vishu@gmail.com`

### Change Colors
Edit: `/app/frontend/src/index.css`
```css
:root {
  --brand-primary: #008055;  /* Your brand color */
  --brand-secondary: #0A6647;
}
```

### Add New Trip
Edit: `/app/frontend/src/data/mockData.js`
Add new object to `featuredTrips` array with all required fields.

---

## 🔧 Troubleshooting

### Frontend won't start
```bash
sudo supervisorctl restart frontend
# or
cd /app/frontend && yarn install && yarn start
```

### Backend errors
```bash
sudo supervisorctl restart backend
# Check logs
tail -f /var/log/supervisor/backend.err.log
```

### Database connection issues
Check MongoDB is running:
```bash
sudo supervisorctl status mongodb
```

---

## 📞 Support Files

- **Editing Guide**: `/app/EDITING_GUIDE.md`
- **Backend Plan**: `/app/BACKEND_PLAN.md`
- **PRD**: `/app/memory/PRD.md`

---

## ✅ What's Included

✅ Complete responsive website (5 pages)
✅ 12 detailed trip packages with itineraries
✅ Backend API with MongoDB integration
✅ Contact form with database storage
✅ Newsletter subscription system
✅ WhatsApp integration
✅ Admin endpoints for data retrieval
✅ Mobile-first design
✅ Toast notifications
✅ Error handling
✅ Loading states
✅ Form validation
✅ SEO-friendly structure
✅ Accessibility features
✅ Production-ready code

---

## 🌐 Live URLs (Current Container)

- **Frontend**: http://localhost:3000
- **Backend API**: Check `/app/frontend/.env` for `REACT_APP_BACKEND_URL`
- **API Docs**: `{BACKEND_URL}/docs` (Swagger UI)

---

## 📤 Export Instructions

To get all code out of the container:

1. **Create archive**:
```bash
cd /app
tar -czf thrillistic-complete.tar.gz \
  frontend/src \
  frontend/public \
  frontend/package.json \
  frontend/tailwind.config.js \
  frontend/craco.config.js \
  backend/server.py \
  backend/models \
  backend/routes \
  backend/requirements.txt \
  *.md
```

2. **Download** the `thrillistic-complete.tar.gz` file

3. **Extract locally**:
```bash
tar -xzf thrillistic-complete.tar.gz
```

---

**Need specific files? Ask me to show you any file's content!**

Example: "Show me the Home.jsx code" or "Show me all API endpoints"
