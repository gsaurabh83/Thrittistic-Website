# Backend Integration Plan - Thrillistic Travel Website

## Current State: Frontend with Mock Data
All data is currently hardcoded in `/app/frontend/src/data/mockData.js`

## Phase 2: Backend Development Plan

### API Contracts

#### 1. Contact Form Submission
```
POST /api/contact/submit
Request Body:
{
  "name": "John Doe",
  "email": "john@example.com",
  "phone": "+91 9876543210",
  "tripInterest": "Ladakh Motorcycle Odyssey",
  "travelers": "2",
  "message": "Interested in booking for March"
}

Response: 201 Created
{
  "success": true,
  "message": "Quote request submitted successfully",
  "submissionId": "abc123"
}
```

#### 2. Newsletter Subscription
```
POST /api/newsletter/subscribe
Request Body:
{
  "email": "user@example.com"
}

Response: 201 Created
{
  "success": true,
  "message": "Subscribed successfully"
}
```

#### 3. Get All Trips (Optional - for dynamic content)
```
GET /api/trips
Response: 200 OK
{
  "trips": [...array of trip objects]
}

GET /api/trips/:id
Response: 200 OK
{
  "trip": {...single trip object}
}
```

### MongoDB Collections

#### 1. contact_submissions
```javascript
{
  _id: ObjectId,
  name: String,
  email: String,
  phone: String,
  tripInterest: String,
  travelers: String,
  message: String,
  submittedAt: Date,
  status: String // 'new', 'contacted', 'converted', 'closed'
}
```

#### 2. newsletter_subscribers
```javascript
{
  _id: ObjectId,
  email: String,
  subscribedAt: Date,
  status: String // 'active', 'unsubscribed'
}
```

#### 3. trips (Optional - for future CMS)
```javascript
{
  _id: ObjectId,
  name: String,
  duration: String,
  price: String,
  difficulty: String,
  region: String,
  budget: String,
  season: String,
  description: String,
  itinerary: [String],
  inclusions: String,
  image: String,
  featured: Boolean,
  active: Boolean
}
```

### Frontend Integration Points

#### Files to Update:
1. `/app/frontend/src/pages/Contact.jsx` - Connect form to API
2. `/app/frontend/src/pages/Home.jsx` - Newsletter signup
3. `/app/frontend/src/pages/Blog.jsx` - Newsletter signup
4. `/app/frontend/src/pages/Destinations.jsx` - Optional: Fetch trips from API

### Implementation Priority

**Phase 2A: Essential Backend (Now)**
- ✅ Contact form submission API
- ✅ Newsletter subscription API
- ✅ MongoDB models
- ✅ Frontend integration

**Phase 2B: Admin Features (Later)**
- Admin dashboard for viewing submissions
- Email notifications on new submissions
- Export submissions to CSV

**Phase 2C: Dynamic Content (Future)**
- Trip management API (CRUD)
- Blog management API (CRUD)
- Content CMS for non-technical updates

---

## Next Steps
1. Create MongoDB models in backend
2. Build API endpoints
3. Update frontend to use real APIs instead of WhatsApp fallback
4. Test end-to-end flow
5. Deploy and monitor
