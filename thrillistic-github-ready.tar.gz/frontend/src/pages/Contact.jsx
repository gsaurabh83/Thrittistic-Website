import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Phone, Mail, MapPin, MessageCircle, Send, CheckCircle, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import axios from 'axios';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '../components/ui/accordion';
import { faqs } from '../data/mockData';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const Contact = () => {
  const location = useLocation();
  const tripName = location.state?.tripName || '';
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    tripInterest: tripName,
    message: '',
    travelers: '1'
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const response = await axios.post(`${BACKEND_URL}/api/contact/submit`, formData);
      
      if (response.data.success) {
        toast.success(response.data.message, {
          icon: <CheckCircle className="text-green-600" />,
          duration: 5000
        });
        
        // Reset form
        setFormData({
          name: '',
          email: '',
          phone: '',
          tripInterest: '',
          message: '',
          travelers: '1'
        });
        
        // Optional: Also send to WhatsApp
        const whatsappMessage = `Hi Thrillistic!%0A%0AName: ${formData.name}%0AEmail: ${formData.email}%0APhone: ${formData.phone}%0AInterested in: ${formData.tripInterest}%0ANumber of travelers: ${formData.travelers}%0A%0AMessage: ${formData.message}`;
        setTimeout(() => {
          window.open(`https://wa.me/919310191560?text=${whatsappMessage}`, '_blank');
        }, 1000);
      }
    } catch (error) {
      console.error('Form submission error:', error);
      toast.error('Failed to submit form. Please try WhatsApp instead.', {
        icon: <AlertCircle className="text-red-600" />,
        duration: 5000
      });
      
      // Fallback to WhatsApp
      const whatsappMessage = `Hi Thrillistic!%0A%0AName: ${formData.name}%0AEmail: ${formData.email}%0APhone: ${formData.phone}%0AInterested in: ${formData.tripInterest}%0ANumber of travelers: ${formData.travelers}%0A%0AMessage: ${formData.message}`;
      window.open(`https://wa.me/919310191560?text=${whatsappMessage}`, '_blank');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-white py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="heading-large mb-4">Get in Touch</h1>
          <p className="body-large text-[var(--text-secondary)] max-w-2xl mx-auto">
            Ready to start your adventure? We're here to help plan your perfect trip
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Contact Form */}
          <div className="lg:col-span-2">
            <div className="bg-white border border-[var(--border-medium)] rounded-xl p-8">
              <h2 className="heading-medium mb-6">Send Us a Message</h2>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="body-standard font-medium mb-2 block">
                      Your Name *
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-[var(--border-medium)] rounded-lg form-input"
                      placeholder="John Doe"
                    />
                  </div>
                  <div>
                    <label className="body-standard font-medium mb-2 block">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-[var(--border-medium)] rounded-lg form-input"
                      placeholder="john@example.com"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="body-standard font-medium mb-2 block">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-[var(--border-medium)] rounded-lg form-input"
                      placeholder="+91 9876543210"
                    />
                  </div>
                  <div>
                    <label className="body-standard font-medium mb-2 block">
                      Number of Travelers
                    </label>
                    <select
                      name="travelers"
                      value={formData.travelers}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-[var(--border-medium)] rounded-lg form-input"
                    >
                      <option value="1">1 Person</option>
                      <option value="2">2 People</option>
                      <option value="3-5">3-5 People</option>
                      <option value="6-10">6-10 People</option>
                      <option value="10+">10+ People</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="body-standard font-medium mb-2 block">
                    Trip Interest
                  </label>
                  <select
                    name="tripInterest"
                    value={formData.tripInterest}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-[var(--border-medium)] rounded-lg form-input"
                  >
                    <option value="">Select a trip...</option>
                    <option value="Ladakh Motorcycle Odyssey">Ladakh Motorcycle Odyssey</option>
                    <option value="Rishikesh White Water Rafting">Rishikesh White Water Rafting</option>
                    <option value="Rajasthan Royal Circuit">Rajasthan Royal Circuit</option>
                    <option value="Kashmir Paradise Retreat">Kashmir Paradise Retreat</option>
                    <option value="Andaman Tropical Paradise">Andaman Tropical Paradise</option>
                    <option value="Meghalaya Living Root Bridges Trek">Meghalaya Living Root Bridges Trek</option>
                    <option value="Kerala Backwaters & Munnar">Kerala Backwaters & Munnar</option>
                    <option value="Kashi Spiritual Sojourn">Kashi Spiritual Sojourn</option>
                    <option value="Custom Trip">Custom Trip</option>
                  </select>
                </div>

                <div>
                  <label className="body-standard font-medium mb-2 block">
                    Your Message *
                  </label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={5}
                    className="w-full px-4 py-3 border border-[var(--border-medium)] rounded-lg form-input resize-none"
                    placeholder="Tell us about your travel plans, preferences, or any questions you have..."
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="btn-primary w-full flex items-center justify-center space-x-2 hover-scale disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? (
                    <>
                      <div className="spinner" />
                      <span>Submitting...</span>
                    </>
                  ) : (
                    <>
                      <Send size={18} />
                      <span>Submit Request</span>
                    </>
                  )}
                </button>

                <p className="body-small text-[var(--text-secondary)] text-center">
                  By submitting this form, you agree to receive communications from Thrillistic
                </p>
              </form>
            </div>

            {/* Google Form Integration */}
            <div className="mt-8 bg-[var(--bg-light)] rounded-xl p-8">
              <h3 className="heading-medium text-base mb-4">Prefer Google Forms?</h3>
              <p className="body-standard text-[var(--text-secondary)] mb-4">
                Fill out our detailed travel preferences form to get personalized recommendations
              </p>
              <a
                href="https://forms.gle/your-google-form-id"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-secondary inline-block"
              >
                Open Google Form
              </a>
            </div>
          </div>

          {/* Contact Info Sidebar */}
          <div className="space-y-8">
            {/* Quick Contact */}
            <div className="bg-[var(--bg-light)] rounded-xl p-6">
              <h3 className="heading-medium text-base mb-6">Quick Contact</h3>
              <div className="space-y-4">
                <a
                  href="tel:+919310191560"
                  className="flex items-start space-x-3 p-3 rounded-lg hover:bg-white transition-colors"
                >
                  <Phone className="text-[var(--brand-primary)] flex-shrink-0 mt-1" size={20} />
                  <div>
                    <div className="body-standard font-medium">Call Us</div>
                    <div className="body-small text-[var(--text-secondary)]">+91 9310191560</div>
                  </div>
                </a>

                <a
                  href="mailto:ajit.vishu@gmail.com"
                  className="flex items-start space-x-3 p-3 rounded-lg hover:bg-white transition-colors"
                >
                  <Mail className="text-[var(--brand-primary)] flex-shrink-0 mt-1" size={20} />
                  <div>
                    <div className="body-standard font-medium">Email Us</div>
                    <div className="body-small text-[var(--text-secondary)] break-all">ajit.vishu@gmail.com</div>
                  </div>
                </a>

                <a
                  href="https://wa.me/919310191560"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-start space-x-3 p-3 rounded-lg hover:bg-white transition-colors"
                >
                  <MessageCircle className="text-[var(--brand-primary)] flex-shrink-0 mt-1" size={20} />
                  <div>
                    <div className="body-standard font-medium">WhatsApp</div>
                    <div className="body-small text-[var(--text-secondary)]">Chat with us instantly</div>
                  </div>
                </a>

                <div className="flex items-start space-x-3 p-3">
                  <MapPin className="text-[var(--brand-primary)] flex-shrink-0 mt-1" size={20} />
                  <div>
                    <div className="body-standard font-medium">Location</div>
                    <div className="body-small text-[var(--text-secondary)]">
                      Adventure HQ, New Delhi, India
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Office Hours */}
            <div className="bg-[var(--bg-light)] rounded-xl p-6">
              <h3 className="heading-medium text-base mb-4">Office Hours</h3>
              <div className="space-y-2">
                <div className="flex justify-between body-standard">
                  <span className="text-[var(--text-secondary)]">Monday - Friday</span>
                  <span className="font-medium">9:00 AM - 7:00 PM</span>
                </div>
                <div className="flex justify-between body-standard">
                  <span className="text-[var(--text-secondary)]">Saturday</span>
                  <span className="font-medium">10:00 AM - 5:00 PM</span>
                </div>
                <div className="flex justify-between body-standard">
                  <span className="text-[var(--text-secondary)]">Sunday</span>
                  <span className="font-medium">Closed</span>
                </div>
              </div>
              <p className="body-small text-[var(--text-secondary)] mt-4">
                24/7 Emergency support available for active trips
              </p>
            </div>

            {/* Social Media */}
            <div className="bg-[var(--bg-light)] rounded-xl p-6">
              <h3 className="heading-medium text-base mb-4">Follow Our Adventures</h3>
              <div className="space-y-3">
                <a
                  href="https://www.instagram.com/thrillistictravelsdelhi"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block body-standard text-[var(--brand-primary)] hover:underline"
                >
                  @thrillistictravelsdelhi
                </a>
                <a
                  href="https://www.instagram.com/ajitvishwanath"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block body-standard text-[var(--brand-primary)] hover:underline"
                >
                  @ajitvishwanath
                </a>
                <a
                  href="https://www.youtube.com/@ajitvishwanath"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block body-standard text-[var(--brand-primary)] hover:underline"
                >
                  YouTube Channel
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Google Maps */}
        <div className="mt-12">
          <h2 className="heading-medium mb-6">Our Adventure Hubs</h2>
          <div className="bg-[var(--bg-light)] rounded-xl p-4 h-96">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d224345.83923192563!2d77.06889754725782!3d28.52758200617607!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cfd5b347eb62d%3A0x52c2b7494e204dce!2sNew%20Delhi%2C%20Delhi!5e0!3m2!1sen!2sin!4v1234567890123"
              width="100%"
              height="100%"
              style={{ border: 0, borderRadius: '8px' }}
              allowFullScreen=""
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Thrillistic Location"
            />
          </div>
        </div>

        {/* FAQ Section */}
        <div className="mt-20">
          <div className="text-center mb-12">
            <h2 className="heading-large mb-4">Frequently Asked Questions</h2>
            <p className="body-large text-[var(--text-secondary)]">
              Quick answers to common questions
            </p>
          </div>

          <div className="max-w-3xl mx-auto">
            <Accordion type="single" collapsible className="space-y-4">
              {faqs.map((faq) => (
                <AccordionItem
                  key={faq.id}
                  value={`item-${faq.id}`}
                  className="bg-white border border-[var(--border-medium)] rounded-lg px-6"
                >
                  <AccordionTrigger className="body-standard font-medium hover:no-underline">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="body-standard text-[var(--text-secondary)]">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
