import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Clock, MapPin, TrendingUp, X } from 'lucide-react';
import { featuredTrips } from '../data/mockData';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '../components/ui/dialog';

const Destinations = () => {
  const [searchParams] = useSearchParams();
  const [filters, setFilters] = useState({
    budget: 'all',
    difficulty: 'all',
    duration: 'all',
    region: 'all'
  });
  const [selectedTrip, setSelectedTrip] = useState(null);
  const [filteredTrips, setFilteredTrips] = useState(featuredTrips);

  // Open modal if trip ID in URL
  useEffect(() => {
    const tripId = searchParams.get('trip');
    if (tripId) {
      const trip = featuredTrips.find(t => t.id === parseInt(tripId));
      if (trip) setSelectedTrip(trip);
    }
  }, [searchParams]);

  // Filter trips
  useEffect(() => {
    let filtered = featuredTrips;

    if (filters.budget !== 'all') {
      filtered = filtered.filter(trip => trip.budget === filters.budget);
    }
    if (filters.difficulty !== 'all') {
      filtered = filtered.filter(trip => trip.difficulty === filters.difficulty);
    }
    if (filters.duration !== 'all') {
      const durationMap = {
        'Weekend': (d) => d.includes('3 Days') || d.includes('2 Days'),
        '3-7 days': (d) => {
          const days = parseInt(d);
          return days >= 3 && days <= 7;
        },
        '7+ days': (d) => {
          const days = parseInt(d);
          return days > 7;
        }
      };
      filtered = filtered.filter(trip => durationMap[filters.duration]?.(trip.duration));
    }
    if (filters.region !== 'all') {
      filtered = filtered.filter(trip => trip.region === filters.region);
    }

    setFilteredTrips(filtered);
  }, [filters]);

  const handleFilterChange = (filterType, value) => {
    setFilters(prev => ({ ...prev, [filterType]: value }));
  };

  const getDifficultyClass = (difficulty) => {
    const classes = {
      'Chill': 'difficulty-chill',
      'Easy': 'difficulty-easy',
      'Moderate': 'difficulty-moderate',
      'Hard': 'difficulty-hard',
      'Extreme': 'difficulty-extreme'
    };
    return classes[difficulty] || 'difficulty-easy';
  };

  const FilterButton = ({ active, onClick, children }) => (
    <button
      onClick={onClick}
      className={`btn-secondary ${active ? 'filter-btn-active' : ''}`}
    >
      {children}
    </button>
  );

  return (
    <div className="min-h-screen bg-white py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="heading-large mb-4">Explore Destinations</h1>
          <p className="body-large text-[var(--text-secondary)] max-w-2xl mx-auto">
            Filter and find your perfect Indian adventure
          </p>
        </div>

        {/* Filters */}
        <div className="mb-12 space-y-6">
          {/* Budget Filter */}
          <div>
            <h3 className="body-standard font-semibold mb-3">Budget</h3>
            <div className="flex flex-wrap gap-2">
              <FilterButton
                active={filters.budget === 'all'}
                onClick={() => handleFilterChange('budget', 'all')}
              >
                All Budgets
              </FilterButton>
              <FilterButton
                active={filters.budget === 'Under 10k'}
                onClick={() => handleFilterChange('budget', 'Under 10k')}
              >
                Under ₹10,000
              </FilterButton>
              <FilterButton
                active={filters.budget === '10-25k'}
                onClick={() => handleFilterChange('budget', '10-25k')}
              >
                ₹10,000 - ₹25,000
              </FilterButton>
              <FilterButton
                active={filters.budget === '25k+'}
                onClick={() => handleFilterChange('budget', '25k+')}
              >
                ₹25,000+
              </FilterButton>
            </div>
          </div>

          {/* Difficulty Filter */}
          <div>
            <h3 className="body-standard font-semibold mb-3">Adventure Level</h3>
            <div className="flex flex-wrap gap-2">
              <FilterButton
                active={filters.difficulty === 'all'}
                onClick={() => handleFilterChange('difficulty', 'all')}
              >
                All Levels
              </FilterButton>
              <FilterButton
                active={filters.difficulty === 'Chill'}
                onClick={() => handleFilterChange('difficulty', 'Chill')}
              >
                Chill
              </FilterButton>
              <FilterButton
                active={filters.difficulty === 'Easy'}
                onClick={() => handleFilterChange('difficulty', 'Easy')}
              >
                Easy
              </FilterButton>
              <FilterButton
                active={filters.difficulty === 'Moderate'}
                onClick={() => handleFilterChange('difficulty', 'Moderate')}
              >
                Moderate
              </FilterButton>
              <FilterButton
                active={filters.difficulty === 'Hard'}
                onClick={() => handleFilterChange('difficulty', 'Hard')}
              >
                Hard
              </FilterButton>
              <FilterButton
                active={filters.difficulty === 'Extreme'}
                onClick={() => handleFilterChange('difficulty', 'Extreme')}
              >
                Extreme
              </FilterButton>
            </div>
          </div>

          {/* Duration Filter */}
          <div>
            <h3 className="body-standard font-semibold mb-3">Duration</h3>
            <div className="flex flex-wrap gap-2">
              <FilterButton
                active={filters.duration === 'all'}
                onClick={() => handleFilterChange('duration', 'all')}
              >
                All Durations
              </FilterButton>
              <FilterButton
                active={filters.duration === 'Weekend'}
                onClick={() => handleFilterChange('duration', 'Weekend')}
              >
                Weekend (2-3 days)
              </FilterButton>
              <FilterButton
                active={filters.duration === '3-7 days'}
                onClick={() => handleFilterChange('duration', '3-7 days')}
              >
                3-7 days
              </FilterButton>
              <FilterButton
                active={filters.duration === '7+ days'}
                onClick={() => handleFilterChange('duration', '7+ days')}
              >
                7+ days
              </FilterButton>
            </div>
          </div>

          {/* Region Filter */}
          <div>
            <h3 className="body-standard font-semibold mb-3">Region</h3>
            <div className="flex flex-wrap gap-2">
              <FilterButton
                active={filters.region === 'all'}
                onClick={() => handleFilterChange('region', 'all')}
              >
                All Regions
              </FilterButton>
              <FilterButton
                active={filters.region === 'North'}
                onClick={() => handleFilterChange('region', 'North')}
              >
                North India
              </FilterButton>
              <FilterButton
                active={filters.region === 'South'}
                onClick={() => handleFilterChange('region', 'South')}
              >
                South India
              </FilterButton>
              <FilterButton
                active={filters.region === 'East'}
                onClick={() => handleFilterChange('region', 'East')}
              >
                East India
              </FilterButton>
              <FilterButton
                active={filters.region === 'West'}
                onClick={() => handleFilterChange('region', 'West')}
              >
                West India
              </FilterButton>
            </div>
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-8">
          <p className="body-standard text-[var(--text-secondary)]">
            Showing {filteredTrips.length} {filteredTrips.length === 1 ? 'trip' : 'trips'}
          </p>
        </div>

        {/* Trip Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredTrips.map((trip) => (
            <div
              key={trip.id}
              className="trip-card bg-white rounded-xl overflow-hidden border border-[var(--border-medium)] cursor-pointer"
              onClick={() => setSelectedTrip(trip)}
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={trip.image}
                  alt={trip.name}
                  className="w-full h-full object-cover"
                />
                <div className="image-overlay" />
                <div className="absolute top-3 right-3">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyClass(trip.difficulty)}`}>
                    {trip.difficulty}
                  </span>
                </div>
                <div className="absolute bottom-3 left-3 right-3">
                  <h3 className="body-standard font-semibold text-white line-clamp-2">
                    {trip.name}
                  </h3>
                </div>
              </div>
              <div className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-1 text-[var(--text-secondary)]">
                    <Clock size={14} />
                    <span className="body-small">{trip.duration}</span>
                  </div>
                  <div className="body-small font-semibold text-[var(--brand-primary)]">
                    {trip.price}
                  </div>
                </div>
                <div className="flex items-center space-x-1 text-[var(--text-secondary)] mb-3">
                  <MapPin size={14} />
                  <span className="body-small">{trip.region} India</span>
                </div>
                <button className="btn-secondary w-full text-sm">
                  View Details
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* No Results */}
        {filteredTrips.length === 0 && (
          <div className="text-center py-12">
            <p className="body-large text-[var(--text-secondary)] mb-4">
              No trips found matching your filters
            </p>
            <button
              onClick={() => setFilters({ budget: 'all', difficulty: 'all', duration: 'all', region: 'all' })}
              className="btn-primary"
            >
              Clear All Filters
            </button>
          </div>
        )}
      </div>

      {/* Trip Details Modal */}
      <Dialog open={!!selectedTrip} onOpenChange={() => setSelectedTrip(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          {selectedTrip && (
            <>
              <DialogHeader>
                <DialogTitle className="heading-medium pr-8">{selectedTrip.name}</DialogTitle>
              </DialogHeader>
              <div className="space-y-6">
                <img
                  src={selectedTrip.image}
                  alt={selectedTrip.name}
                  className="w-full h-64 object-cover rounded-lg"
                />
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <p className="body-small text-[var(--text-secondary)]">Duration</p>
                    <p className="body-standard font-semibold">{selectedTrip.duration}</p>
                  </div>
                  <div>
                    <p className="body-small text-[var(--text-secondary)]">Price Range</p>
                    <p className="body-standard font-semibold text-[var(--brand-primary)]">{selectedTrip.price}</p>
                  </div>
                  <div>
                    <p className="body-small text-[var(--text-secondary)]">Difficulty</p>
                    <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${getDifficultyClass(selectedTrip.difficulty)}`}>
                      {selectedTrip.difficulty}
                    </span>
                  </div>
                  <div>
                    <p className="body-small text-[var(--text-secondary)]">Best Season</p>
                    <p className="body-standard font-semibold">{selectedTrip.season}</p>
                  </div>
                </div>

                <div>
                  <h4 className="heading-medium text-base mb-2">Description</h4>
                  <p className="body-standard text-[var(--text-secondary)]">{selectedTrip.description}</p>
                </div>

                <div>
                  <h4 className="heading-medium text-base mb-3">Itinerary</h4>
                  <div className="space-y-2">
                    {selectedTrip.itinerary.map((day, index) => (
                      <div key={index} className="flex items-start space-x-3">
                        <div className="w-6 h-6 rounded-full bg-[var(--brand-primary)] text-white flex items-center justify-center flex-shrink-0 text-xs font-semibold">
                          {index + 1}
                        </div>
                        <p className="body-small text-[var(--text-secondary)] flex-1">{day}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="heading-medium text-base mb-2">Inclusions</h4>
                  <p className="body-small text-[var(--text-secondary)]">{selectedTrip.inclusions}</p>
                </div>

                <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-[var(--border-medium)]">
                  <Link
                    to="/contact"
                    state={{ tripName: selectedTrip.name }}
                    className="btn-primary flex-1 text-center"
                  >
                    Request Quote
                  </Link>
                  <a
                    href="https://wa.me/919310191560?text=Hi, I'm interested in booking a trip"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-secondary flex-1 text-center"
                  >
                    WhatsApp Us
                  </a>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Destinations;
