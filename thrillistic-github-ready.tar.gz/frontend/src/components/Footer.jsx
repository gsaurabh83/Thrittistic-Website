import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Facebook, Instagram, Youtube } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[var(--bg-light)] pt-16 pb-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Company Info */}
          <div>
            <h3 className="heading-medium mb-4" style={{ color: 'var(--brand-primary)' }}>
              Thrillistic
            </h3>
            <p className="body-small text-[var(--text-secondary)] mb-4">
              Curated Thrilling Adventures Across India – Adventure Redefined, Memories Guaranteed
            </p>
            <div className="flex space-x-4">
              <a
                href="https://www.instagram.com/thrillistictravelsdelhi"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[var(--text-secondary)] hover:text-[var(--brand-primary)] transition-colors"
                aria-label="Instagram"
              >
                <Instagram size={20} />
              </a>
              <a
                href="https://www.instagram.com/ajitvishwanath"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[var(--text-secondary)] hover:text-[var(--brand-primary)] transition-colors"
                aria-label="Instagram Personal"
              >
                <Instagram size={20} />
              </a>
              <a
                href="https://www.youtube.com/@ajitvishwanath"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[var(--text-secondary)] hover:text-[var(--brand-primary)] transition-colors"
                aria-label="YouTube"
              >
                <Youtube size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="heading-medium text-base mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="body-small text-[var(--text-secondary)] hover:text-[var(--brand-primary)] transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/about" className="body-small text-[var(--text-secondary)] hover:text-[var(--brand-primary)] transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/destinations" className="body-small text-[var(--text-secondary)] hover:text-[var(--brand-primary)] transition-colors">
                  Destinations
                </Link>
              </li>
              <li>
                <Link to="/blog" className="body-small text-[var(--text-secondary)] hover:text-[var(--brand-primary)] transition-colors">
                  Blog
                </Link>
              </li>
              <li>
                <Link to="/contact" className="body-small text-[var(--text-secondary)] hover:text-[var(--brand-primary)] transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          {/* Popular Destinations */}
          <div>
            <h4 className="heading-medium text-base mb-4">Popular Destinations</h4>
            <ul className="space-y-2">
              <li className="body-small text-[var(--text-secondary)]">Ladakh Motorcycle Tours</li>
              <li className="body-small text-[var(--text-secondary)]">Rishikesh Rafting</li>
              <li className="body-small text-[var(--text-secondary)]">Kashmir Valleys</li>
              <li className="body-small text-[var(--text-secondary)]">Rajasthan Desert Safari</li>
              <li className="body-small text-[var(--text-secondary)]">Andaman Islands</li>
              <li className="body-small text-[var(--text-secondary)]">Meghalaya Treks</li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="heading-medium text-base mb-4">Contact Us</h4>
            <ul className="space-y-3">
              <li className="flex items-start space-x-2">
                <Phone size={18} className="text-[var(--brand-primary)] mt-1 flex-shrink-0" />
                <a href="tel:+919310191560" className="body-small text-[var(--text-secondary)] hover:text-[var(--brand-primary)] transition-colors">
                  +91 9310191560
                </a>
              </li>
              <li className="flex items-start space-x-2">
                <Mail size={18} className="text-[var(--brand-primary)] mt-1 flex-shrink-0" />
                <a href="mailto:ajit.vishu@gmail.com" className="body-small text-[var(--text-secondary)] hover:text-[var(--brand-primary)] transition-colors break-all">
                  ajit.vishu@gmail.com
                </a>
              </li>
              <li className="flex items-start space-x-2">
                <MapPin size={18} className="text-[var(--brand-primary)] mt-1 flex-shrink-0" />
                <span className="body-small text-[var(--text-secondary)]">
                  Adventure HQ, New Delhi, India
                </span>
              </li>
            </ul>
          </div>
        </div>

        {/* Trust Signals */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 py-8 border-t border-[var(--border-medium)]">
          <div className="text-center">
            <div className="heading-large text-[var(--brand-primary)]">10+</div>
            <div className="body-small text-[var(--text-secondary)]">Years Experience</div>
          </div>
          <div className="text-center">
            <div className="heading-large text-[var(--brand-primary)]">5000+</div>
            <div className="body-small text-[var(--text-secondary)]">Happy Travelers</div>
          </div>
          <div className="text-center">
            <div className="heading-large text-[var(--brand-primary)]">50+</div>
            <div className="body-small text-[var(--text-secondary)]">Destinations</div>
          </div>
          <div className="text-center">
            <div className="heading-large text-[var(--brand-primary)]">100%</div>
            <div className="body-small text-[var(--text-secondary)]">Fully Insured</div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-[var(--border-medium)] pt-8 text-center">
          <p className="body-small text-[var(--text-secondary)]">
            © {currentYear} Thrillistic. All rights reserved. | Curating thrilling adventures across India since 2014
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
