import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone, Mail } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Destinations', path: '/destinations' },
    { name: 'Blog', path: '/blog' },
    { name: 'Contact', path: '/contact' }
  ];

  return (
    <header className={`sticky-header ${isScrolled ? 'scrolled' : ''}`}>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between py-4">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <div className="text-2xl font-semibold" style={{ color: 'var(--brand-primary)' }}>
              Thrillistic
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`body-standard transition-colors hover:text-[var(--brand-primary)] ${
                  location.pathname === link.path
                    ? 'text-[var(--brand-primary)] font-medium'
                    : 'text-[var(--text-secondary)]'
                }`}
              >
                {link.name}
              </Link>
            ))}
          </nav>

          {/* Contact Info & CTA */}
          <div className="hidden md:flex items-center space-x-4">
            <a 
              href="tel:+919310191560" 
              className="flex items-center space-x-2 text-[var(--text-secondary)] hover:text-[var(--brand-primary)] transition-colors"
            >
              <Phone size={18} />
              <span className="body-small">+91 9310191560</span>
            </a>
            <Link to="/contact" className="btn-primary">
              Start Your Adventure
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-[var(--border-medium)]">
            <nav className="flex flex-col space-y-4">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`body-standard transition-colors ${
                    location.pathname === link.path
                      ? 'text-[var(--brand-primary)] font-medium'
                      : 'text-[var(--text-secondary)]'
                  }`}
                  onClick={() => setIsMenuOpen(false)}
                >
                  {link.name}
                </Link>
              ))}
              <div className="flex flex-col space-y-2 pt-4 border-t border-[var(--border-medium)]">
                <a 
                  href="tel:+919310191560" 
                  className="flex items-center space-x-2 text-[var(--text-secondary)]"
                >
                  <Phone size={18} />
                  <span className="body-small">+91 9310191560</span>
                </a>
                <a 
                  href="mailto:ajit.vishu@gmail.com" 
                  className="flex items-center space-x-2 text-[var(--text-secondary)]"
                >
                  <Mail size={18} />
                  <span className="body-small">ajit.vishu@gmail.com</span>
                </a>
                <Link to="/contact" className="btn-primary w-full text-center mt-2">
                  Start Your Adventure
                </Link>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
