import React from 'react';
import { MessageCircle } from 'lucide-react';

const WhatsAppFloat = () => {
  return (
    <a
      href="https://wa.me/919310191560?text=Hi%20Thrillistic!%20I'm%20interested%20in%20booking%20a%20trip"
      target="_blank"
      rel="noopener noreferrer"
      className="whatsapp-float"
      aria-label="Chat on WhatsApp"
    >
      <MessageCircle size={28} color="white" />
    </a>
  );
};

export default WhatsAppFloat;
