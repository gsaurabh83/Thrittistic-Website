from fastapi import APIRouter, HTTPException, status
from models.thrillistic import (
    ContactSubmissionCreate,
    ContactSubmission,
    NewsletterSubscriptionCreate,
    NewsletterSubscription,
    SuccessResponse,
    ErrorResponse,
    SubmissionStatus
)
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from datetime import datetime

router = APIRouter(prefix="/api", tags=["thrillistic"])
logger = logging.getLogger(__name__)

# MongoDB connection (imported from main app)
def get_db():
    mongo_url = os.environ.get('MONGO_URL')
    client = AsyncIOMotorClient(mongo_url)
    db = client[os.environ.get('DB_NAME', 'thrillistic_db')]
    return db

@router.post("/contact/submit", response_model=SuccessResponse, status_code=status.HTTP_201_CREATED)
async def submit_contact_form(submission: ContactSubmissionCreate):
    """
    Submit a contact form / quote request
    """
    try:
        db = get_db()
        
        # Create submission object with metadata
        submission_data = ContactSubmission(**submission.dict())
        
        # Insert into MongoDB
        result = await db.contact_submissions.insert_one(submission_data.dict())
        
        logger.info(f"Contact form submitted: {submission.email} - {submission.tripInterest}")
        
        return SuccessResponse(
            success=True,
            message="Quote request submitted successfully! We'll get back to you within 24 hours.",
            submissionId=submission_data.id
        )
    
    except Exception as e:
        logger.error(f"Error submitting contact form: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to submit form. Please try again or contact us directly."
        )

@router.post("/newsletter/subscribe", response_model=SuccessResponse, status_code=status.HTTP_201_CREATED)
async def subscribe_newsletter(subscription: NewsletterSubscriptionCreate):
    """
    Subscribe to newsletter
    """
    try:
        db = get_db()
        
        # Check if email already exists
        existing = await db.newsletter_subscribers.find_one({"email": subscription.email})
        
        if existing:
            # If already subscribed and active
            if existing.get('status') == 'active':
                return SuccessResponse(
                    success=True,
                    message="You're already subscribed to our newsletter!"
                )
            else:
                # Reactivate subscription
                await db.newsletter_subscribers.update_one(
                    {"email": subscription.email},
                    {"$set": {"status": "active", "subscribedAt": datetime.utcnow()}}
                )
                return SuccessResponse(
                    success=True,
                    message="Welcome back! Your subscription has been reactivated."
                )
        
        # Create new subscription
        subscription_data = NewsletterSubscription(**subscription.dict())
        await db.newsletter_subscribers.insert_one(subscription_data.dict())
        
        logger.info(f"Newsletter subscription: {subscription.email}")
        
        return SuccessResponse(
            success=True,
            message="Successfully subscribed! Check your email for exclusive deals.",
            submissionId=subscription_data.id
        )
    
    except Exception as e:
        logger.error(f"Error subscribing to newsletter: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to subscribe. Please try again."
        )

@router.get("/contact/submissions", response_model=dict)
async def get_all_submissions(skip: int = 0, limit: int = 50):
    """
    Get all contact form submissions (Admin use)
    """
    try:
        db = get_db()
        
        submissions = await db.contact_submissions.find().sort("submittedAt", -1).skip(skip).limit(limit).to_list(limit)
        total = await db.contact_submissions.count_documents({})
        
        # Convert ObjectId to string
        for submission in submissions:
            if '_id' in submission:
                submission['_id'] = str(submission['_id'])
        
        return {
            "success": True,
            "submissions": submissions,
            "total": total,
            "skip": skip,
            "limit": limit
        }
    
    except Exception as e:
        logger.error(f"Error fetching submissions: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch submissions"
        )

@router.get("/newsletter/subscribers", response_model=dict)
async def get_all_subscribers(skip: int = 0, limit: int = 100):
    """
    Get all newsletter subscribers (Admin use)
    """
    try:
        db = get_db()
        
        subscribers = await db.newsletter_subscribers.find({"status": "active"}).sort("subscribedAt", -1).skip(skip).limit(limit).to_list(limit)
        total = await db.newsletter_subscribers.count_documents({"status": "active"})
        
        # Convert ObjectId to string
        for subscriber in subscribers:
            if '_id' in subscriber:
                subscriber['_id'] = str(subscriber['_id'])
        
        return {
            "success": True,
            "subscribers": subscribers,
            "total": total,
            "skip": skip,
            "limit": limit
        }
    
    except Exception as e:
        logger.error(f"Error fetching subscribers: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch subscribers"
        )

@router.get("/health")
async def health_check():
    """
    Health check endpoint
    """
    return {
        "status": "healthy",
        "service": "Thrillistic API",
        "timestamp": datetime.utcnow().isoformat()
    }
