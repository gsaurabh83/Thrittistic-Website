# 🌄 Thrillistic Travel Website

Complete, production-ready travel website for Thrillistic - Curated thrilling adventures across India.

## 🌟 Features

- **5-Page Responsive Website**: Home, About, Destinations, Blog, Contact
- **12 Adventure Packages**: Detailed itineraries with pricing, difficulty levels, and seasons
- **Backend API**: FastAPI with MongoDB for form submissions and subscriptions
- **Contact System**: Form submissions stored in database + WhatsApp integration
- **Newsletter**: Email subscription with duplicate detection
- **Professional UI**: Following $20k+ agency design standards
- **Mobile-First**: Perfect responsive design for all devices

## 🎯 Live Preview

- **Homepage**: Hero slider with 8 Indian destinations
- **Destinations**: Advanced filtering (budget, difficulty, duration, region)
- **About**: Interactive quiz to find perfect trip
- **Contact**: Multi-channel contact with FAQ accordion

## 🛠️ Tech Stack

### Frontend
- React 19.0.0
- TailwindCSS + Custom Design System
- Shadcn UI (Radix UI primitives)
- React Router v7.5.1
- Axios for API calls
- Sonner for notifications
- Lucide React icons

### Backend
- FastAPI 0.110.1
- Motor (async MongoDB driver)
- Pydantic for validation
- Python 3.11+

### Database
- MongoDB with collections for contacts and subscribers

## 📦 Installation

### Prerequisites
- Node.js 18+ and Yarn
- Python 3.11+
- MongoDB

### Frontend Setup
```bash
cd frontend
yarn install
cp .env.example .env
# Edit .env with your backend URL
yarn start
```
Runs on http://localhost:3000

### Backend Setup
```bash
cd backend
pip install -r requirements.txt
cp .env.example .env
# Edit .env with your MongoDB URL
uvicorn server:app --reload --host 0.0.0.0 --port 8001
```
Runs on http://localhost:8001

## ⚙️ Configuration

### Frontend Environment Variables
Create `frontend/.env`:
```env
REACT_APP_BACKEND_URL=http://localhost:8001
```

For production:
```env
REACT_APP_BACKEND_URL=https://api.thrillistic.com
```

### Backend Environment Variables
Create `backend/.env`:
```env
MONGO_URL=mongodb://localhost:27017
DB_NAME=thrillistic_db
```

For MongoDB Atlas (production):
```env
MONGO_URL=mongodb+srv://username:password@cluster.mongodb.net/
DB_NAME=thrillistic_production
```

## 🎨 Customization

### Edit Trip Prices
File: `frontend/src/data/mockData.js`
```javascript
{
  id: 1,
  name: "Ladakh Motorcycle Odyssey",
  price: "₹45,000 - ₹55,000"  // ← Change here
}
```

### Update Contact Info
Search and replace in:
- `frontend/src/components/Header.jsx`
- `frontend/src/components/Footer.jsx`
- `frontend/src/pages/Contact.jsx`

Current: `+91 9310191560` and `ajit.vishu@gmail.com`

### Change Brand Colors
File: `frontend/src/index.css`
```css
:root {
  --brand-primary: #008055;  /* Your brand color */
  --brand-secondary: #0A6647;
}
```

## 📚 API Documentation

### Endpoints

**Contact Form**
- `POST /api/contact/submit` - Submit contact form
- `GET /api/contact/submissions` - Get all submissions (admin)

**Newsletter**
- `POST /api/newsletter/subscribe` - Subscribe to newsletter
- `GET /api/newsletter/subscribers` - Get subscribers (admin)

**Health**
- `GET /api/health` - Health check

API docs available at: `http://localhost:8001/docs` (Swagger UI)

## 🚀 Deployment

### Frontend Options
- **Vercel** (Recommended): Connect GitHub repo, auto-deploy
- **Netlify**: Drag & drop or GitHub integration
- **AWS S3 + CloudFront**: Static hosting

### Backend Options
- **Railway**: GitHub auto-deploy with environment variables
- **Heroku**: Git push deployment
- **DigitalOcean App Platform**: GitHub integration
- **AWS EC2**: Full control VPS

### Database
- **MongoDB Atlas**: Free tier available, fully managed
- **Self-hosted**: DigitalOcean MongoDB droplet

## 📄 Documentation

- [EDITING_GUIDE.md](EDITING_GUIDE.md) - How to edit prices and content
- [CODE_ACCESS_GUIDE.md](CODE_ACCESS_GUIDE.md) - Complete file structure
- [DEPLOYMENT_SUMMARY.md](DEPLOYMENT_SUMMARY.md) - Production deployment
- [BACKEND_PLAN.md](BACKEND_PLAN.md) - API documentation
- [GITHUB_DEPLOYMENT_GUIDE.md](GITHUB_DEPLOYMENT_GUIDE.md) - Deploy to GitHub

## 🧪 Testing

**Verified & Working:**
- ✅ Contact form submission → MongoDB
- ✅ Newsletter subscription → MongoDB  
- ✅ WhatsApp integration
- ✅ Form validation
- ✅ Toast notifications
- ✅ Responsive design (mobile & desktop)
- ✅ All navigation
- ✅ Filter system
- ✅ Hero slider auto-play

## 🎯 Project Structure

```
thrillistic-website/
├── frontend/               # React application
│   ├── src/
│   │   ├── components/    # Reusable components
│   │   ├── pages/         # Page components
│   │   ├── data/          # Mock data & content
│   │   └── hooks/         # Custom React hooks
│   ├── public/            # Static assets
│   └── package.json
│
├── backend/               # FastAPI application
│   ├── models/           # Pydantic models
│   ├── routes/           # API endpoints
│   ├── server.py         # Main application
│   └── requirements.txt
│
└── Documentation files
```

## 🔐 Security

- ✅ Input validation (Pydantic)
- ✅ CORS configuration
- ✅ Email validation
- ✅ Environment variables for secrets
- ⚠️ Add rate limiting for production
- ⚠️ Enable MongoDB authentication
- ⚠️ Use HTTPS in production

## 📈 Performance

- Target: <3s page load time
- Optimized images from Unsplash
- Code splitting with React lazy loading
- Async MongoDB queries
- Hot reload in development

## 📝 License

Proprietary - All rights reserved by Thrillistic

## 👥 Contact & Support

- **Website**: thrillistic.com
- **Phone**: +91 9310191560
- **Email**: ajit.vishu@gmail.com
- **YouTube**: [@ajitvishwanath](https://www.youtube.com/@ajitvishwanath)
- **Instagram**: [@thrillistictravelsdelhi](https://www.instagram.com/thrillistictravelsdelhi)

---

**Built with ❤️ for adventure seekers across India**
