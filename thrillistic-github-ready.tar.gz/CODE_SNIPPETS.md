# Thrillistic - Key Code Snippets

## 🏠 Homepage Hero Slider Component

```jsx
// /app/frontend/src/pages/Home.jsx (Simplified)

import React, { useState, useEffect } from 'react';
import { heroSlides } from '../data/mockData';

const Home = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  // Auto-advance slider every 5 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="relative h-screen">
      {heroSlides.map((slide, index) => (
        <div
          key={slide.id}
          className={`absolute inset-0 transition-opacity duration-1000 ${
            index === currentSlide ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <img src={slide.image} alt={slide.title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent" />
        </div>
      ))}
      
      <div className="absolute inset-0 flex items-center justify-center z-10">
        <h1 className="display-hero text-white text-center">
          Curated Thrilling Adventures<br />Across India
        </h1>
      </div>
    </section>
  );
};
```

---

## 🎯 Contact Form with Backend Integration

```jsx
// /app/frontend/src/pages/Contact.jsx (Simplified)

import React, { useState } from 'react';
import axios from 'axios';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '', email: '', phone: '', tripInterest: '', message: '', travelers: '1'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const response = await axios.post(`${BACKEND_URL}/api/contact/submit`, formData);
      
      if (response.data.success) {
        toast.success(response.data.message);
        setFormData({ name: '', email: '', phone: '', tripInterest: '', message: '', travelers: '1' });
        
        // Also send to WhatsApp
        const msg = `Name: ${formData.name}, Email: ${formData.email}, Trip: ${formData.tripInterest}`;
        window.open(`https://wa.me/919310191560?text=${encodeURIComponent(msg)}`, '_blank');
      }
    } catch (error) {
      toast.error('Failed to submit. Please try WhatsApp.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="name" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} />
      <input name="email" type="email" value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} />
      <button type="submit" disabled={isSubmitting}>
        {isSubmitting ? 'Submitting...' : 'Submit Request'}
      </button>
    </form>
  );
};
```

---

## 🔧 Backend API - Contact Form Endpoint

```python
# /app/backend/routes/thrillistic.py

from fastapi import APIRouter, HTTPException, status
from models.thrillistic import ContactSubmissionCreate, ContactSubmission, SuccessResponse
from motor.motor_asyncio import AsyncIOMotorClient
import os

router = APIRouter(prefix="/api")

def get_db():
    mongo_url = os.environ.get('MONGO_URL')
    client = AsyncIOMotorClient(mongo_url)
    return client[os.environ.get('DB_NAME', 'thrillistic_db')]

@router.post("/contact/submit", response_model=SuccessResponse, status_code=status.HTTP_201_CREATED)
async def submit_contact_form(submission: ContactSubmissionCreate):
    """Submit contact form and store in MongoDB"""
    try:
        db = get_db()
        submission_data = ContactSubmission(**submission.dict())
        await db.contact_submissions.insert_one(submission_data.dict())
        
        return SuccessResponse(
            success=True,
            message="Quote request submitted successfully! We'll get back to you within 24 hours.",
            submissionId=submission_data.id
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to submit form"
        )
```

---

## 📊 Pydantic Models

```python
# /app/backend/models/thrillistic.py

from pydantic import BaseModel, EmailStr, Field
from datetime import datetime
from enum import Enum

class SubmissionStatus(str, Enum):
    NEW = "new"
    CONTACTED = "contacted"
    CONVERTED = "converted"
    CLOSED = "closed"

class ContactSubmissionCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    email: EmailStr
    phone: str = Field(..., min_length=10, max_length=20)
    tripInterest: str = Field(default="", max_length=200)
    travelers: str = Field(default="1")
    message: str = Field(..., min_length=10, max_length=2000)

class ContactSubmission(ContactSubmissionCreate):
    id: str = Field(default_factory=lambda: str(__import__('uuid').uuid4()))
    submittedAt: datetime = Field(default_factory=datetime.utcnow)
    status: SubmissionStatus = Field(default=SubmissionStatus.NEW)
```

---

## 🎨 Design System CSS

```css
/* /app/frontend/src/index.css */

@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

:root {
  /* Brand Colors */
  --brand-primary: #008055;
  --brand-secondary: #0A6647;
  --brand-dark: #124E3B;
  
  /* Gradient Colors */
  --gradient-coral: #D98A8C;
  --gradient-yellow: #E1C567;
  --gradient-orange: #DFB573;
  
  /* Text Colors */
  --text-primary: #0A0A0A;
  --text-secondary: #3C3B3D;
  --text-muted: #AFADB2;
}

/* Button Styles */
.btn-primary {
  background: var(--brand-primary);
  color: white;
  border: none;
  border-radius: 26px; /* Pill shape */
  padding: 18px 24px;
  font-size: 16px;
  transition: all 0.2s ease;
}

.btn-primary:hover {
  background: var(--brand-secondary);
  transform: scale(1.02);
}

/* Typography */
.display-hero {
  font-size: 56px;
  font-weight: 500;
  line-height: 1.1;
  letter-spacing: -0.02em;
}

@media (max-width: 809px) {
  .display-hero {
    font-size: 36px;
  }
}
```

---

## 🗂️ Mock Data Structure

```javascript
// /app/frontend/src/data/mockData.js

export const featuredTrips = [
  {
    id: 1,
    name: "Ladakh Motorcycle Odyssey",
    image: "https://images.unsplash.com/...",
    duration: "8 Days / 7 Nights",
    price: "₹45,000 - ₹55,000",
    difficulty: "Extreme",
    region: "North",
    budget: "25k+",
    season: "June - September",
    description: "Epic motorcycle journey through world's highest motorable passes...",
    itinerary: [
      "Day 1: Arrival in Leh, acclimatization",
      "Day 2: Leh to Nubra Valley via Khardung La (18,380 ft)",
      // ... 8 days total
    ],
    inclusions: "Royal Enfield bikes, permits, fuel, accommodation, meals, guide..."
  },
  // ... 11 more trips
];

export const testimonials = [
  {
    id: 1,
    name: "Priya Sharma",
    location: "Mumbai",
    image: "", // Empty for avatar initials
    rating: 5,
    text: "Best trip ever! Ladakh motorcycle odyssey was life-changing..."
  },
  // ... more testimonials
];
```

---

## 🎭 Filter System for Destinations

```jsx
// /app/frontend/src/pages/Destinations.jsx (Simplified)

const [filters, setFilters] = useState({
  budget: 'all',
  difficulty: 'all',
  duration: 'all',
  region: 'all'
});

useEffect(() => {
  let filtered = allTrips;
  
  if (filters.budget !== 'all') {
    filtered = filtered.filter(trip => trip.budget === filters.budget);
  }
  if (filters.difficulty !== 'all') {
    filtered = filtered.filter(trip => trip.difficulty === filters.difficulty);
  }
  // ... more filters
  
  setFilteredTrips(filtered);
}, [filters]);

// Filter buttons
<button 
  onClick={() => setFilters({...filters, budget: '25k+'})}
  className={filters.budget === '25k+' ? 'filter-btn-active' : 'btn-secondary'}
>
  ₹25,000+
</button>
```

---

## 📧 Newsletter Subscription

```jsx
// Home.jsx - Newsletter form

const [newsletterEmail, setNewsletterEmail] = useState('');
const [isSubscribing, setIsSubscribing] = useState(false);

const handleNewsletterSubmit = async (e) => {
  e.preventDefault();
  setIsSubscribing(true);

  try {
    const response = await axios.post(`${BACKEND_URL}/api/newsletter/subscribe`, {
      email: newsletterEmail
    });
    
    if (response.data.success) {
      toast.success(response.data.message);
      setNewsletterEmail('');
    }
  } catch (error) {
    toast.error('Failed to subscribe');
  } finally {
    setIsSubscribing(false);
  }
};

<form onSubmit={handleNewsletterSubmit}>
  <input 
    type="email" 
    value={newsletterEmail}
    onChange={(e) => setNewsletterEmail(e.target.value)}
    placeholder="Enter your email"
  />
  <button type="submit" disabled={isSubscribing}>
    {isSubscribing ? 'Subscribing...' : 'Subscribe'}
  </button>
</form>
```

---

## 🔐 Environment Configuration

```env
# /app/frontend/.env
REACT_APP_BACKEND_URL=your-backend-url-here

# /app/backend/.env
MONGO_URL=mongodb://localhost:27017
DB_NAME=thrillistic_db
```

---

## 📱 Responsive Header Component

```jsx
// /app/frontend/src/components/Header.jsx (Simplified)

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 10);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`sticky-header ${isScrolled ? 'scrolled' : ''}`}>
      {/* Desktop Nav */}
      <nav className="hidden md:flex">
        <Link to="/">Home</Link>
        <Link to="/about">About</Link>
        <Link to="/destinations">Destinations</Link>
      </nav>
      
      {/* Mobile Menu Button */}
      <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
        {isMenuOpen ? <X /> : <Menu />}
      </button>
      
      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden">
          <Link to="/" onClick={() => setIsMenuOpen(false)}>Home</Link>
          {/* ... more links */}
        </div>
      )}
    </header>
  );
};
```

---

## 🎪 Trip Detail Modal

```jsx
// Destinations.jsx - Modal using Shadcn Dialog

import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../components/ui/dialog';

<Dialog open={!!selectedTrip} onOpenChange={() => setSelectedTrip(null)}>
  <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
    {selectedTrip && (
      <>
        <DialogHeader>
          <DialogTitle>{selectedTrip.name}</DialogTitle>
        </DialogHeader>
        
        <img src={selectedTrip.image} alt={selectedTrip.name} />
        
        <div className="grid grid-cols-4 gap-4">
          <div>
            <p>Duration</p>
            <p>{selectedTrip.duration}</p>
          </div>
          <div>
            <p>Price</p>
            <p>{selectedTrip.price}</p>
          </div>
        </div>
        
        <div>
          <h4>Itinerary</h4>
          {selectedTrip.itinerary.map((day, i) => (
            <div key={i}>Day {i + 1}: {day}</div>
          ))}
        </div>
      </>
    )}
  </DialogContent>
</Dialog>
```

---

## 🚀 Main App Router

```jsx
// /app/frontend/src/App.js

import { BrowserRouter, Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import WhatsAppFloat from "./components/WhatsAppFloat";
import { Toaster } from "./components/ui/sonner";

// Pages
import Home from "./pages/Home";
import About from "./pages/About";
import Destinations from "./pages/Destinations";
import Blog from "./pages/Blog";
import Contact from "./pages/Contact";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Header />
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/destinations" element={<Destinations />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/contact" element={<Contact />} />
          </Routes>
        </main>
        <Footer />
        <WhatsAppFloat />
        <Toaster />
      </BrowserRouter>
    </div>
  );
}

export default App;
```

---

## 📦 Package.json Dependencies

```json
{
  "dependencies": {
    "react": "^19.0.0",
    "react-dom": "^19.0.0",
    "react-router-dom": "^7.5.1",
    "axios": "^1.8.4",
    "lucide-react": "^0.507.0",
    "sonner": "^2.0.3",
    "@radix-ui/react-dialog": "^1.1.11",
    "@radix-ui/react-accordion": "^1.2.8",
    "tailwindcss": "^3.4.17"
  }
}
```

---

**All code is available at `/app/thrillistic-source-code.tar.gz` (63KB)**

Download and extract to get the complete codebase!
