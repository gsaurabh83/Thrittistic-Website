# 🚀 Complete GitHub Deployment Guide for Thrillistic

## Step 1: Create Complete Export Package

Run this command to create a clean export with all necessary files:

```bash
cd /app

# Create a complete export excluding unnecessary files
tar -czf thrillistic-github-ready.tar.gz \
  --exclude='node_modules' \
  --exclude='build' \
  --exclude='dist' \
  --exclude='__pycache__' \
  --exclude='.pyc' \
  --exclude='*.log' \
  --exclude='.DS_Store' \
  --exclude='thrillistic-source-code.tar.gz' \
  frontend/ \
  backend/ \
  README.md \
  EDITING_GUIDE.md \
  CODE_ACCESS_GUIDE.md \
  CODE_SNIPPETS.md \
  DEPLOYMENT_SUMMARY.md \
  BACKEND_PLAN.md \
  memory/PRD.md
```

This creates: `/app/thrillistic-github-ready.tar.gz`

---

## Step 2: Download the Archive

### Option A: Using Emergent File Browser
1. Go to your Emergent dashboard
2. Navigate to File Browser
3. Go to `/app/` directory
4. Find `thrillistic-github-ready.tar.gz`
5. Click to download

### Option B: Using Command Line (if you have SSH/terminal access)
```bash
# From your local machine
scp user@your-server:/app/thrillistic-github-ready.tar.gz ./
```

---

## Step 3: Extract Files Locally

On your local machine:

```bash
# Create a project directory
mkdir thrillistic-website
cd thrillistic-website

# Extract the archive
tar -xzf thrillistic-github-ready.tar.gz

# You should now see:
# thrillistic-website/
# ├── frontend/
# ├── backend/
# └── *.md files
```

---

## Step 4: Create Proper Project Structure

```bash
# Add a main README
cat > README.md << 'EOF'
# Thrillistic Travel Website

Complete travel website for Thrillistic - Curated thrilling adventures across India.

## 🌟 Features

- 5-page responsive website (Home, About, Destinations, Blog, Contact)
- 12 detailed adventure trip packages
- Backend API with MongoDB integration
- Contact form with database storage
- Newsletter subscription system
- WhatsApp integration
- Mobile-first design with professional UI

## 🛠️ Tech Stack

**Frontend:**
- React 19.0.0
- TailwindCSS + Shadcn UI
- React Router v7
- Axios

**Backend:**
- FastAPI
- MongoDB (Motor async driver)
- Pydantic validation

## 📦 Installation

### Frontend
```bash
cd frontend
yarn install
yarn start
```

### Backend
```bash
cd backend
pip install -r requirements.txt
uvicorn server:app --reload --host 0.0.0.0 --port 8001
```

## ⚙️ Configuration

### Frontend Environment (.env)
```
REACT_APP_BACKEND_URL=http://localhost:8001
```

### Backend Environment (.env)
```
MONGO_URL=mongodb://localhost:27017
DB_NAME=thrillistic_db
```

## 📚 Documentation

- [Editing Guide](EDITING_GUIDE.md) - How to edit prices and content
- [Code Access Guide](CODE_ACCESS_GUIDE.md) - File structure
- [Deployment Summary](DEPLOYMENT_SUMMARY.md) - Production deployment
- [Backend Plan](BACKEND_PLAN.md) - API documentation

## 🚀 Deployment

Site is ready to deploy on:
- Frontend: Vercel, Netlify, AWS S3
- Backend: Heroku, Railway, DigitalOcean, AWS EC2
- Database: MongoDB Atlas

## 📝 License

Proprietary - All rights reserved by Thrillistic

## 👥 Contact

- Website: thrillistic.com
- Phone: +91 9310191560
- Email: ajit.vishu@gmail.com
EOF

# Create .gitignore
cat > .gitignore << 'EOF'
# Dependencies
node_modules/
__pycache__/
*.pyc
*.pyo
*.pyd
.Python
env/
venv/
ENV/
build/
dist/
*.egg-info/

# Environment variables
.env
.env.local
.env.production

# Build outputs
frontend/build/
frontend/.next/
backend/dist/

# IDE
.vscode/
.idea/
*.swp
*.swo
*~
.DS_Store

# Logs
*.log
logs/
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# Testing
coverage/
.pytest_cache/

# Misc
.cache/
temp/
tmp/
*.tar.gz
*.zip
EOF
```

---

## Step 5: Create Environment Templates

```bash
# Frontend environment template
cat > frontend/.env.example << 'EOF'
# Backend API URL
REACT_APP_BACKEND_URL=http://localhost:8001

# For production, replace with your actual backend URL:
# REACT_APP_BACKEND_URL=https://api.thrillistic.com
EOF

# Backend environment template
cat > backend/.env.example << 'EOF'
# MongoDB Connection
MONGO_URL=mongodb://localhost:27017

# Database Name
DB_NAME=thrillistic_db

# For production with MongoDB Atlas:
# MONGO_URL=mongodb+srv://username:password@cluster.mongodb.net/
# DB_NAME=thrillistic_production
EOF

# Copy to actual .env files (with your values)
cp frontend/.env.example frontend/.env
cp backend/.env.example backend/.env

# Edit these files with your actual values
nano frontend/.env
nano backend/.env
```

---

## Step 6: Initialize Git Repository

```bash
# Initialize git
git init

# Add all files
git add .

# Create initial commit
git commit -m "Initial commit: Thrillistic travel website

- Complete React frontend with 5 pages
- FastAPI backend with MongoDB integration
- 12 adventure trip packages
- Contact form and newsletter subscription
- Mobile-responsive design
- WhatsApp integration"
```

---

## Step 7: Create GitHub Repository

### On GitHub.com:
1. Go to https://github.com/new
2. Repository name: `thrillistic-website` (or your choice)
3. Description: "Thrillistic Travel Website - Curated adventure trips across India"
4. Choose: **Private** (recommended for client work)
5. **DO NOT** initialize with README (we already have one)
6. Click "Create repository"

---

## Step 8: Push to GitHub

```bash
# Add GitHub remote (replace with your repo URL)
git remote add origin https://github.com/YOUR_USERNAME/thrillistic-website.git

# Push to GitHub
git branch -M main
git push -u origin main
```

If you have 2FA enabled on GitHub:
```bash
# Use personal access token instead of password
# Generate token at: https://github.com/settings/tokens
# Use token as password when prompted
```

---

## Step 9: Verify Upload

1. Go to your GitHub repository
2. Check all files are present:
   - ✅ frontend/ directory
   - ✅ backend/ directory
   - ✅ README.md
   - ✅ .gitignore
   - ✅ Documentation files

3. Verify .env files are NOT uploaded (should be in .gitignore)

---

## Step 10: Set Up GitHub Secrets (for CI/CD later)

If you plan to use GitHub Actions for deployment:

1. Go to repository Settings → Secrets and variables → Actions
2. Add secrets:
   - `MONGO_URL` - Your MongoDB connection string
   - `REACT_APP_BACKEND_URL` - Your production backend URL
   - Other sensitive keys

---

## 📁 Final Directory Structure on GitHub

```
thrillistic-website/
├── .gitignore
├── README.md
├── EDITING_GUIDE.md
├── CODE_ACCESS_GUIDE.md
├── CODE_SNIPPETS.md
├── DEPLOYMENT_SUMMARY.md
├── BACKEND_PLAN.md
│
├── frontend/
│   ├── public/
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── data/
│   │   ├── hooks/
│   │   ├── App.js
│   │   └── index.js
│   ├── package.json
│   ├── tailwind.config.js
│   ├── craco.config.js
│   ├── .env.example
│   └── .env (not in git)
│
├── backend/
│   ├── models/
│   ├── routes/
│   ├── server.py
│   ├── requirements.txt
│   ├── .env.example
│   └── .env (not in git)
│
└── memory/
    └── PRD.md
```

---

## 🚀 Quick Commands Reference

```bash
# 1. Create export
cd /app && tar -czf thrillistic-github-ready.tar.gz \
  --exclude='node_modules' --exclude='build' \
  frontend/ backend/ *.md memory/

# 2. Extract locally
tar -xzf thrillistic-github-ready.tar.gz

# 3. Initialize git
git init
git add .
git commit -m "Initial commit"

# 4. Push to GitHub
git remote add origin https://github.com/YOUR_USERNAME/thrillistic-website.git
git branch -M main
git push -u origin main
```

---

## 🔄 Making Updates Later

```bash
# Make your changes to files
# Then:

git add .
git commit -m "Update trip prices and add new destination"
git push origin main
```

---

## 🌐 Deploy from GitHub

### Frontend (Vercel - Recommended)
```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
cd frontend
vercel

# Follow prompts, set environment variables in Vercel dashboard
```

### Frontend (Netlify)
1. Go to https://app.netlify.com
2. "New site from Git"
3. Connect GitHub
4. Select repository
5. Build command: `cd frontend && yarn build`
6. Publish directory: `frontend/build`
7. Add environment variables

### Backend (Railway)
1. Go to https://railway.app
2. "New Project" → "Deploy from GitHub repo"
3. Select your repository
4. Set root directory: `backend`
5. Add environment variables (MONGO_URL, DB_NAME)
6. Railway will auto-detect FastAPI and deploy

### Backend (Heroku)
```bash
# Create Procfile in backend/
cd backend
echo "web: uvicorn server:app --host 0.0.0.0 --port \$PORT" > Procfile

# Deploy
heroku create thrillistic-api
git subtree push --prefix backend heroku main
```

---

## ✅ Post-Upload Checklist

- [ ] Repository created on GitHub
- [ ] All code files pushed
- [ ] .env files NOT in repository (in .gitignore)
- [ ] README.md displays correctly
- [ ] Clone test: `git clone` and verify it works
- [ ] Environment templates (.env.example) included
- [ ] Documentation files accessible

---

## 🔐 Security Notes

**NEVER commit these files:**
- `.env` (contains sensitive keys)
- `node_modules/` (too large)
- `build/` or `dist/` (generated files)
- Log files
- Database dumps

**Always use:**
- `.env.example` templates for documentation
- GitHub Secrets for CI/CD credentials
- Environment variables in production

---

## 🆘 Troubleshooting

### "Permission denied" when pushing
```bash
# Use HTTPS with personal access token
git remote set-url origin https://YOUR_TOKEN@github.com/YOUR_USERNAME/thrillistic-website.git
```

### Large file error
```bash
# If accidentally added large files
git rm --cached path/to/large/file
git commit --amend
```

### Files not uploading
```bash
# Check .gitignore isn't blocking them
git check-ignore -v path/to/file
```

---

## 📞 Need Help?

If you encounter issues:
1. Check GitHub's documentation: https://docs.github.com
2. Verify .gitignore is correct
3. Ensure .env files are properly excluded
4. Test with a small test repository first

---

**Your code is now ready for GitHub! 🎉**
EOF
cat /app/GITHUB_DEPLOYMENT_GUIDE.md